/**
 * WebGuard policy engine — REAL, deterministic, no model inside (PRD 6.5 §1.2;
 * PRD 4 §40–42; PRD 5 §8–15; PRD 6 §5). Fixed evaluation order:
 * schema → type → target+generation → provenance → sensitivity gate →
 * confirmation classification → parameter rules. First failure decides.
 */
import { validateStructuredAction } from "../../../../shared/types.js";
const CONFIRM_SUBMIT_RE = /submit|place order|buy|pay|purchase|send|delete|remove|upload|confirm/i;
function needsConfirmation(action, target) {
    if (target !== null && target.isSubmit)
        return true;
    if (target !== null && CONFIRM_SUBMIT_RE.test(target.name) && target.role === "button") {
        return true;
    }
    if (action.action === "close_tab")
        return false;
    return false;
}
export function evaluate(action, ctx) {
    // 1. Schema: malformed proposals die here, never downstream.
    const checked = validateStructuredAction(action);
    if (!checked.ok) {
        return { decision: "BLOCK", reason: `schema: ${checked.errors.join("; ")}` };
    }
    // 2. Provenance: only the user (via controller) or system policy authorize.
    if (ctx.provenance !== "USER" && ctx.provenance !== "SYSTEM") {
        return { decision: "BLOCK", reason: "provenance: not user-authorized" };
    }
    // 3. Target + generation for target-bearing actions. web_search and
    // browser_search are read-only and targetless (like navigation): ALLOW,
    // never confirm. browser_search navigates via the default search engine
    // (PRD 6.10 §6/§8) — still targetless, still guarded by schema + budgets.
    const needsTarget = !["navigate", "go_back", "go_forward", "close_tab", "web_search", "browser_search"].includes(action.action);
    let target = null;
    if (needsTarget) {
        if (action.target === undefined) {
            return { decision: "BLOCK", reason: "target: required for this action" };
        }
        const known = ctx.targets.get(action.target);
        if (known === undefined) {
            return { decision: "BLOCK", reason: `target: ${action.target} not in current registry` };
        }
        if (action.pageGeneration !== undefined && action.pageGeneration !== ctx.currentGeneration) {
            return { decision: "BLOCK", reason: `stale: action generation ${action.pageGeneration} != current ${ctx.currentGeneration}` };
        }
        target = known;
    }
    else if (action.action === "close_tab" && action.target !== undefined) {
        const known = ctx.targets.get(action.target);
        if (known === undefined) {
            return { decision: "BLOCK", reason: `target: ${action.target} not in current registry` };
        }
    }
    const power = ctx.powerMode === true;
    // 4. Sensitivity gate: secrets are typed only via the authorized slot-fill.
    // Power mode: the operator explicitly accepted typing anywhere.
    if (!power &&
        target !== null &&
        target.sensitive &&
        action.action === "type" &&
        !ctx.sensitiveAuthorized) {
        return {
            decision: "BLOCK",
            reason: "sensitive: value must arrive via the ask-user memory-only path",
        };
    }
    // 5. Confirmation classification for consequential actions.
    // Power mode: no REQUIRE_CONFIRMATION is ever emitted.
    if (!power && needsConfirmation(action, target)) {
        return { decision: "REQUIRE_CONFIRMATION", reason: "consequential action requires explicit approval" };
    }
    return { decision: "ALLOW", reason: power ? "within policy (power mode: safety gates bypassed)" : "within policy" };
}
//# sourceMappingURL=policy.js.map