/**
 * TaskState store — REAL (PRD 6.5; PRD 3 §14–15).
 * Task-scoped: survives navigation, dies on completion/cancel. Persisted in
 * chrome.storage.session (survives SW suspension, dies on browser close).
 * Restart rule (fail closed): any non-terminal task found at startup is
 * marked CANCELLED, never resumed — pending confirmations especially.
 */
import { STORAGE_KEY_TASK } from "../../../../shared/constants.js";
import { logger } from "../../../../shared/logger.js";
const TERMINAL = new Set([
    "COMPLETE",
    "CANCELLED",
    "BLOCKED",
    "FAILED",
    "LIMIT_REACHED",
]);
export function isTerminal(status) {
    return TERMINAL.has(status);
}
export async function saveTask(snapshot) {
    const persist = {
        ...snapshot,
        updatedAt: Date.now(),
    };
    await chrome.storage.session.set({ [STORAGE_KEY_TASK]: persist });
}
export async function loadTask() {
    const stored = await chrome.storage.session.get(STORAGE_KEY_TASK);
    const snapshot = stored[STORAGE_KEY_TASK];
    return snapshot ?? null;
}
export async function clearTask() {
    await chrome.storage.session.remove(STORAGE_KEY_TASK);
}
/**
 * Fail-closed restart: a task that was mid-flight when the worker died is
 * cancelled, with its partial progress preserved for reporting — never resumed,
 * never auto-executed (a stale YES must never become a future execution).
 */
export async function failClosedOnRestart() {
    const snapshot = await loadTask();
    if (snapshot === null || isTerminal(snapshot.status))
        return null;
    const cancelled = {
        ...snapshot,
        status: "CANCELLED",
        updatedAt: Date.now(),
        pendingQuestion: null,
        pendingConfirmation: null,
    };
    await saveTask(cancelled);
    logger.warn("task fail-closed on restart", {
        taskId: snapshot.taskId,
        was: snapshot.status,
    });
    return cancelled;
}
let taskCounter = 0;
export function newTaskId() {
    taskCounter += 1;
    return `task_${Date.now()}_${taskCounter}`;
}
//# sourceMappingURL=store.js.map