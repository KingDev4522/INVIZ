/**
 * Audio Controller: priority queue, preemption, dedupe, half-duplex gate
 * (PRD 3 §47–50; PRD 4 §37, §92–93; PRD 6 §4.3).
 * Backend-agnostic: synthesis/playback are injected, so every scheduling rule
 * is unit-testable without audio hardware. Priority 1 = highest.
 */
import { TTS_AUDIO_CACHE_MAX_BYTES, TTS_MAX_BYTES_PER_REQUEST, } from "../../../shared/constants.js";
import { cacheKey, chunkText, splitMixedSegments, } from "../tts/text-shaping.js";
import { BackendError, } from "../../../shared/api.js";
export class AudioController {
    synth;
    player;
    fallback;
    beeper;
    readCredentials;
    events;
    queue = [];
    order = 0;
    generation = 0;
    current = null;
    lastSignature = null;
    consecutivePrimaryFailures = 0;
    primaryLatchedOff = false;
    draining = false;
    cache = new Map();
    cacheBytes = 0;
    lastSpoken = null;
    constructor(synth, player, fallback, beeper, readCredentials, events = {}) {
        this.synth = synth;
        this.player = player;
        this.fallback = fallback;
        this.beeper = beeper;
        this.readCredentials = readCredentials;
        this.events = events;
    }
    /** True while system speech is audible — capture stays paused (half-duplex). */
    isSpeaking() {
        return this.current !== null;
    }
    queueDepth() {
        return this.queue.length + (this.current !== null ? 1 : 0);
    }
    /**
     * Enqueues one announcement. Returns the disposition for observability.
     * Priority-5 (focus) duplicates of the last utterance are dropped.
     * Higher-priority requests preempt interruptible lower-priority speech.
     */
    enqueue(req) {
        const signature = `${req.lang}|${req.text}`;
        // Focus-announcement dedupe: drop repeats of what just played, is playing,
        // or is already queued — rapid Tab must never stack identical speech.
        if (req.priority === 5) {
            if (signature === this.lastSignature ||
                this.current?.entry.signature === signature ||
                this.queue.some((e) => e.signature === signature)) {
                return { disposition: "deduped" };
            }
        }
        const segments = splitMixedSegments(req.text, req.lang === "hi" ? "hi" : "en").map((s) => ({ text: s.text, lang: (s.lang === "hi" ? "hi" : "en") }));
        const entry = { req, segments, signature, order: this.order++ };
        // Focus takeover: a new focus announcement interrupts a *playing* focus
        // announcement, and replaces focus announcements already waiting in the
        // queue — Tab/hover must only ever speak the element you are on now.
        const focusTakeover = req.priority === 5 && this.current?.entry.req.priority === 5;
        if (req.priority === 5) {
            this.queue = this.queue.filter((e) => e.req.priority !== 5);
        }
        if (this.current !== null &&
            (req.priority < this.current.entry.req.priority || focusTakeover) &&
            this.current.entry.req.interruptible) {
            this.current.stop();
            this.current = null;
            this.queue.unshift(entry);
            void this.drain();
            return { disposition: "preempted" };
        }
        // Stable priority insert: lower number first, FIFO within a level.
        const index = this.queue.findIndex((e) => e.req.priority > req.priority);
        if (index === -1)
            this.queue.push(entry);
        else
            this.queue.splice(index, 0, entry);
        void this.drain();
        return { disposition: "queued" };
    }
    /** Halts current speech and drops interruptible queued items. */
    stop(interruptAll) {
        this.generation += 1;
        const wasSpeaking = this.current !== null;
        const priority = this.current?.entry.req.priority;
        this.current?.stop();
        this.current = null;
        if (wasSpeaking) {
            try {
                this.events.onSpeakingChange?.(false, priority ?? 3);
            }
            catch {
                // Advisory only.
            }
        }
        if (interruptAll) {
            this.queue.length = 0;
        }
        else {
            this.queue = this.queue.filter((e) => !e.req.interruptible);
        }
        this.draining = false;
    }
    beep(kind) {
        this.beeper.beep(kind);
    }
    /** Re-enqueues the last fully spoken utterance (repeat command). */
    repeatLast() {
        if (this.lastSpoken === null)
            return false;
        this.enqueue({
            text: this.lastSpoken.text,
            lang: this.lastSpoken.lang,
            priority: 4,
            interruptible: true,
            requestId: `repeat_${Date.now()}`,
        });
        return true;
    }
    async drain() {
        if (this.draining || this.current !== null)
            return;
        const entry = this.queue.shift();
        if (entry === undefined)
            return;
        this.draining = true;
        const gen = this.generation;
        let stopped = false;
        this.current = {
            entry,
            stop: () => {
                stopped = true;
                try {
                    this.player.stop();
                }
                catch {
                    // Backend already silent.
                }
                try {
                    this.fallback.stop();
                }
                catch {
                    // Backend already silent.
                }
            },
        };
        try {
            this.events.onSpeakingChange?.(true, entry.req.priority);
        }
        catch {
            // Advisory only.
        }
        try {
            await this.playEntry(entry, () => stopped || gen !== this.generation);
            this.lastSignature = entry.signature;
            this.lastSpoken = { text: entry.req.text, lang: entry.req.lang };
        }
        catch {
            // Utterance-level failure already handled per-segment; continue queue.
        }
        finally {
            if (this.current?.entry === entry)
                this.current = null;
            this.draining = false;
            try {
                this.events.onSpeakingChange?.(false, entry.req.priority);
            }
            catch {
                // Advisory only.
            }
            if (this.queue.length > 0)
                void this.drain();
        }
    }
    async playEntry(entry, cancelled) {
        for (const segment of entry.segments) {
            if (cancelled())
                return;
            const text = segment.text;
            if (text.trim() === "")
                continue;
            // Long segments are chunked at sentence boundaries (backend byte caps).
            const chunks = chunkText(text).length > 1 || needsChunking(text)
                ? chunkText(text, TTS_MAX_BYTES_PER_REQUEST)
                : [text];
            for (const chunk of chunks) {
                if (cancelled())
                    return;
                await this.playChunk(chunk, segment.lang, entry.req.priority, cancelled, entry.req.requestId);
            }
        }
        void entry;
    }
    async playChunk(text, lang, _priority, cancelled, requestId) {
        void _priority;
        if (!this.primaryLatchedOff) {
            let blob;
            try {
                blob = await this.synthOrCache(text, lang, requestId);
            }
            catch (err) {
                if (cancelled())
                    return; // interrupted mid-request: stay silent
                if (err instanceof BackendError && (err.status === 401 || err.status === 403)) {
                    this.events.onAuthExpired?.();
                }
                this.consecutivePrimaryFailures += 1;
                if (this.consecutivePrimaryFailures >= 3 && !this.primaryLatchedOff) {
                    this.primaryLatchedOff = true;
                    this.events.onPrimaryLatchedFallback?.();
                }
                // Fall through to local speech for this utterance.
                await this.fallback.speak(text, lang);
                return;
            }
            this.consecutivePrimaryFailures = 0;
            if (cancelled())
                return; // preempted while synthesizing: stay silent
            try {
                await this.player.play(blob);
            }
            catch {
                // Preemption stops the player too — never "recover" by speaking the
                // interrupted text locally. Only real playback faults fall back.
                if (cancelled())
                    return;
                await this.fallback.speak(text, lang);
            }
            return;
        }
        if (cancelled())
            return;
        await this.fallback.speak(text, lang);
    }
    async synthOrCache(text, lang, requestId) {
        const key = cacheKey(text, lang);
        const hit = this.cache.get(key);
        if (hit !== undefined) {
            // LRU touch.
            this.cache.delete(key);
            this.cache.set(key, hit);
            return hit.blob;
        }
        const creds = await this.readCredentials();
        if (creds === null) {
            throw new Error("Backend not configured (URL missing)");
        }
        const blob = await this.synth.synthesize(text, lang, creds, requestId);
        const size = blob.size;
        while (this.cacheBytes + size > TTS_AUDIO_CACHE_MAX_BYTES && this.cache.size > 0) {
            const oldest = this.cache.keys().next();
            if (oldest.done === true)
                break;
            const victim = this.cache.get(oldest.value);
            this.cache.delete(oldest.value);
            this.cacheBytes -= victim?.size ?? 0;
        }
        this.cache.set(key, { blob, size });
        this.cacheBytes += size;
        return blob;
    }
    /** Clears a session latch (e.g. after backend validation passes again). */
    resetPrimary() {
        this.primaryLatchedOff = false;
        this.consecutivePrimaryFailures = 0;
    }
    /** Test introspection: cached entry count. */
    cacheSize() {
        return this.cache.size;
    }
    /** Test introspection: primary latched to fallback. */
    isPrimaryLatchedOff() {
        return this.primaryLatchedOff;
    }
}
function needsChunking(text) {
    return new TextEncoder().encode(text).length > TTS_MAX_BYTES_PER_REQUEST;
}
//# sourceMappingURL=audio-controller.js.map