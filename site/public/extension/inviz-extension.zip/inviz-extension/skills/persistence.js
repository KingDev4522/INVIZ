import { validateSkill } from "../../../shared/skill-validation.js";
import { skillContentHash, stableStringify, } from "../../../shared/skill-integrity.js";
export const SKILL_STORE_SCHEMA_VERSION = 1;
export const MAX_PERSISTED_SKILLS = 128;
export const MAX_PERSISTED_BYTES = 262_144; // 256 KiB
/** A replaceable, dependency-free store for tests and non-extension contexts. */
export class MemorySkillStore {
    value = null;
    async load() {
        return this.value;
    }
    async save(serialized) {
        this.value = serialized;
    }
    async clear() {
        this.value = null;
    }
}
function buildFile(skills, now) {
    const records = [];
    for (const skill of skills) {
        records.push({
            contentHash: skillContentHash(skill),
            status: skill.status,
            skill: { ...skill },
        });
    }
    return { schemaVersion: SKILL_STORE_SCHEMA_VERSION, savedAt: now, records };
}
/**
 * Serializes a skill set, enforcing the count bound. Never throws on oversize —
 * it drops the surplus and reports it, so a runaway skill set cannot wedge the
 * extension by failing every save.
 */
export function serializeSkills(skills, now = Date.now()) {
    const skipped = [];
    const kept = [];
    for (const skill of skills) {
        if (kept.length >= MAX_PERSISTED_SKILLS) {
            skipped.push(`${skill.id}@${skill.version}: exceeds skill count bound`);
            continue;
        }
        kept.push(skill);
    }
    const serialized = stableStringify(buildFile(kept, now));
    return { serialized, saved: kept.length, skipped };
}
/** Serializes + persists the registry's full version set. */
export async function persistRegistry(store, registry, now = Date.now()) {
    const { serialized, saved, skipped } = serializeSkills(registry.exportSkills(), now);
    const bytes = serialized.length;
    if (bytes > MAX_PERSISTED_BYTES) {
        // Refuse to write an oversized blob rather than silently truncating it.
        return {
            ok: false,
            saved: 0,
            skipped,
            bytes,
            error: `serialized skills exceed ${MAX_PERSISTED_BYTES} byte bound`,
        };
    }
    try {
        await store.save(serialized);
    }
    catch (err) {
        return {
            ok: false,
            saved: 0,
            skipped,
            bytes,
            error: err instanceof Error ? err.message : "persistence write failed",
        };
    }
    return { ok: true, saved, skipped, bytes };
}
function parseFile(raw) {
    if (raw.length > MAX_PERSISTED_BYTES) {
        return { error: `persisted skills exceed ${MAX_PERSISTED_BYTES} byte bound` };
    }
    let parsed;
    try {
        parsed = JSON.parse(raw);
    }
    catch {
        return { error: "persisted skills are not valid JSON" };
    }
    if (typeof parsed !== "object" || parsed === null || Array.isArray(parsed)) {
        return { error: "persisted skills must be an object" };
    }
    const file = parsed;
    if (file.schemaVersion !== SKILL_STORE_SCHEMA_VERSION) {
        return { error: `unsupported persisted schema version ${String(file.schemaVersion)}` };
    }
    if (!Array.isArray(file.records)) {
        return { error: "persisted records must be an array" };
    }
    if (file.records.length > MAX_PERSISTED_SKILLS) {
        return { error: `persisted records exceed ${MAX_PERSISTED_SKILLS} entry bound` };
    }
    return { file: file };
}
/**
 * Loads a persisted skill set into a registry. Built-ins are registered first
 * by the caller, so a persisted record that matches an existing id+version
 * restores its TRUST STATE only (via applyPersistedState); a record for an
 * unknown id/version is registered as a full definition. Anything malformed,
 * hash-mismatched, or otherwise invalid is rejected and reported — never
 * repaired, never trusted implicitly.
 */
export async function loadRegistryFromStore(store, registry) {
    const rejected = [];
    let applied = 0;
    let registered = 0;
    let raw;
    try {
        raw = await store.load();
    }
    catch (err) {
        rejected.push(err instanceof Error ? err.message : "persistence read failed");
        return { applied, registered, rejected };
    }
    if (raw === null || raw === "")
        return { applied, registered, rejected };
    const { file, error } = parseFile(raw);
    if (file === undefined) {
        rejected.push(error ?? "invalid persisted skills");
        return { applied, registered, rejected };
    }
    for (const record of file.records) {
        if (typeof record !== "object" || record === null) {
            rejected.push("record: must be an object");
            continue;
        }
        const skill = record.skill;
        const validation = validateSkill(skill);
        if (!validation.valid) {
            rejected.push(`invalid record: ${validation.errors.join("; ")}`);
            continue;
        }
        const typed = skill;
        const expectedHash = record.contentHash;
        if (expectedHash !== skillContentHash(typed)) {
            rejected.push(`${typed.id}@${typed.version}: content hash mismatch`);
            continue;
        }
        const existing = registry.getVersion(typed.id, typed.version);
        if (existing !== null) {
            // Restore TRUST STATE only. applyPersistedState re-checks the content
            // hash against the registered implementation and never mutates the
            // definition, so a persisted file can change a skill's trust but never
            // its behaviour.
            const result = registry.applyPersistedState(typed);
            if (!result.ok) {
                rejected.push(`${typed.id}@${typed.version}: ${result.error ?? "rejected"}`);
                continue;
            }
            applied += 1;
        }
        else {
            const result = registry.register(typed, { approval: { approver: "persisted" } });
            if (!result.ok) {
                rejected.push(`${typed.id}@${typed.version}: ${result.errors.join("; ")}`);
                continue;
            }
            registered += 1;
        }
    }
    return { applied, registered, rejected };
}
/**
 * Persists the registry on every mutation. Returns a detach function. Write
 * failures are swallowed (a save must never break a running task) but the last
 * error is exposed for diagnostics.
 */
export function attachPersistence(store, registry, now = () => Date.now()) {
    let lastError = null;
    const persist = () => {
        void persistRegistry(store, registry, now()).then((result) => {
            lastError = result.ok ? null : (result.error ?? null);
        });
    };
    const detach = registry.onChange(persist);
    return { detach, lastError: () => lastError };
}
//# sourceMappingURL=persistence.js.map