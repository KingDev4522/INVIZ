import { createSkillCatalog } from "../plan.js";
import { genericFindElement } from "./generic-find-element.js";
import { genericReadRegion } from "./generic-read-region.js";
import { githubFindContributors } from "./github-find-contributors.js";
export const BUILTIN_SKILLS = [
    githubFindContributors,
    genericReadRegion,
    genericFindElement,
];
/** Fresh catalog of the built-in skills. */
export function createBuiltinCatalog() {
    return createSkillCatalog(BUILTIN_SKILLS);
}
/**
 * Registers every built-in skill into the given registry. A skill that fails
 * Phase 1 validation is reported and skipped — never force-registered.
 */
export function registerBuiltinSkills(registry) {
    const registered = [];
    const errors = [];
    for (const entry of BUILTIN_SKILLS) {
        const result = registry.register(entry.skill);
        if (result.ok) {
            registered.push(entry.skill.id);
        }
        else {
            errors.push(`${entry.skill.id}: ${result.errors.join("; ")}`);
        }
    }
    return { registered, errors };
}
//# sourceMappingURL=index.js.map