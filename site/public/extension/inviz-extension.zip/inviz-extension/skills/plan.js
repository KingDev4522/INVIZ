/**
 * Skill planning — REAL (Phase 2).
 *
 * A skill does not execute anything. Given the CURRENT verified page state and
 * resolved inputs, a skill's resolver PRODUCES a plan: an ordered list of
 * concrete StructuredActions plus verification criteria and a result summary.
 *
 * The plan is then executed by the EXISTING INVIZ pipeline (WebGuard →
 * Browser Executor → Verification) in a later phase. Nothing here bypasses
 * that pipeline — this module only builds the actions that will flow through it.
 *
 * Security invariants enforced here:
 *  - Unknown skill ids fail closed (unknown_skill).
 *  - Disabled/candidate skills fail closed (not_executable) — the registry's
 *    trust gate is consulted before any resolver runs.
 *  - Every generated action is re-validated with the SAME closed schema
 *    WebGuard uses (validateStructuredAction); a plan producing anything else
 *    is rejected wholesale (invalid_plan). This is what makes "no arbitrary
 *    JavaScript / no CDP / no shell" structural rather than aspirational.
 *  - The page generation of every action is stamped from the snapshot the plan
 *    was derived from, so a plan can never claim a generation it did not see.
 */
import { validateStructuredAction, } from "../../../shared/types.js";
export function createSkillCatalog(entries) {
    const byId = new Map();
    for (const entry of entries)
        byId.set(entry.skill.id, entry);
    return {
        get: (id) => byId.get(id) ?? null,
        list: () => [...byId.values()],
    };
}
/**
 * Actions after which a skill is considered finished for the current step, so
 * the controller hands control back to the model. `read` yields the observation
 * the user asked for; `focus` completes a locate-and-surface skill. Everything
 * else (click/navigate/type/…) is a transition and the skill is re-resolved
 * against the FRESH page state on the next step — never executed blindly as a
 * batch.
 */
const TERMINAL_SKILL_ACTIONS = new Set([
    "read",
    "focus",
    "web_search",
    "close_tab",
]);
export function isTerminalSkillAction(action) {
    return TERMINAL_SKILL_ACTIONS.has(action);
}
/**
 * Compact capability advertisement for the model's [AVAILABLE SKILLS] section.
 * Lists ONLY executable (tested/approved/trusted, enabled) skills. Returns ""
 * when none exist, so the section is omitted entirely.
 *
 * This is capability metadata, never a procedure: the model names an id and
 * supplies inputs; the trusted registry holds the actual steps.
 */
export function describeAvailableSkills(registry) {
    const lines = [];
    for (const summary of registry.discover()) {
        // The registry's execution policy is authoritative: candidates, disabled,
        // and any withheld `tested`/`canary` skills are not advertised.
        if (!registry.isExecutable(summary.id))
            continue;
        const inputs = registry.get(summary.id)?.requiredInputs ?? [];
        const inputText = inputs.length === 0
            ? "none"
            : inputs.map((i) => `${i.name}${i.required ? " (required)" : "?"}`).join(", ");
        lines.push(`- ${summary.id}: ${summary.description} inputs: ${inputText}`);
    }
    if (lines.length === 0)
        return "";
    lines.push('Emit {"type":"skill","skill_id":"<id>","input":{...}} to run one of these instead of low-level steps.');
    return lines.join("\n");
}
// --- Shared resolution helpers (pure, reused by every built-in skill) --------
const ELEMENT_HANDLE_RE = /^e\d+$/;
const REGION_HANDLE_RE = /^r\d+$/;
export function isElementHandle(id) {
    return ELEMENT_HANDLE_RE.test(id);
}
export function isRegionHandle(id) {
    return REGION_HANDLE_RE.test(id);
}
/** Case/space-insensitive name comparison key. Never a selector. */
export function normalizedName(value) {
    return value.replace(/\s+/g, " ").trim().toLowerCase();
}
/** First `max` characters of readable text, single-spaced — never HTML. */
export function excerpt(text, max = 60) {
    const clean = text.replace(/\s+/g, " ").trim();
    return clean.length <= max ? clean : clean.slice(0, max).trimEnd();
}
// --- The fail-closed plan gate ----------------------------------------------
function denied(skillId, version, pageGeneration, status, reason) {
    return {
        skillId,
        skillVersion: version,
        pageGeneration,
        status,
        reason,
        actions: [],
        verification: [],
        result: {},
    };
}
/**
 * Builds a plan for one skill against the current page state.
 *
 * Order of gates:
 *  1. catalog entry present? else unknown_skill.
 *  2. registry has it? else unknown_skill.
 *  3. registry says executable? else not_executable (disabled/candidate).
 *  4. run the resolver.
 *  5. re-validate EVERY generated action against the closed schema; any
 *     failure rejects the whole plan (invalid_plan). pageGeneration is stamped
 *     from the snapshot.
 *
 * Never throws — a resolver that throws becomes invalid_plan, so a faulty
 * skill cannot crash the agent.
 */
export function planSkill(args) {
    const { registry, catalog, skillId, snapshot } = args;
    const inputs = args.inputs ?? {};
    const generation = snapshot.generation;
    const entry = catalog.get(skillId);
    if (entry === null) {
        return denied(skillId, "0.0.0", generation, "unknown_skill", `unknown skill "${skillId}"`);
    }
    const version = entry.skill.version;
    const registered = registry.get(skillId);
    if (registered === null) {
        return denied(skillId, version, generation, "unknown_skill", `skill "${skillId}" is not registered`);
    }
    // A plan may only run the implementation the trusted catalog defines. If the
    // active version differs from the catalog's, the code and metadata disagree —
    // fail closed rather than run an unknown implementation.
    if (registered.version !== version) {
        return denied(skillId, version, generation, "not_executable", `active version ${registered.version} does not match skill version ${version}`);
    }
    if (!registry.isExecutable(skillId)) {
        return denied(skillId, version, generation, "not_executable", `skill "${skillId}" is ${registered.status} and cannot execute`);
    }
    let draft;
    try {
        draft = entry.resolve(snapshot, inputs);
    }
    catch (err) {
        return denied(skillId, version, generation, "invalid_plan", `resolver failed: ${err instanceof Error ? err.message : "unknown error"}`);
    }
    // Stamp the generation from the snapshot this plan was derived from.
    const actions = (draft.actions ?? []).map((action) => ({
        ...action,
        pageGeneration: generation,
    }));
    // Fail closed: every generated action must satisfy the SAME closed schema
    // WebGuard enforces. Unknown action types, smuggled fields, bad targets, and
    // non-http(s) URLs are all rejected here.
    for (const action of actions) {
        const checked = validateStructuredAction(action);
        if (!checked.ok) {
            return denied(skillId, version, generation, "invalid_plan", `generated action rejected: ${checked.errors.join("; ")}`);
        }
    }
    return {
        skillId,
        skillVersion: version,
        pageGeneration: generation,
        status: draft.status,
        ...(draft.reason !== undefined ? { reason: draft.reason } : {}),
        actions,
        verification: draft.verification ?? [],
        result: draft.result ?? {},
    };
}
//# sourceMappingURL=plan.js.map