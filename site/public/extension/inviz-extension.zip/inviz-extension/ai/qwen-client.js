import { BackendError, ENDPOINTS, } from "../../../shared/api.js";
import { validateModelOutput, ModelOutputError, } from "../../../shared/response-validator.js";
import { logger } from "../../../shared/logger.js";
/**
 * Reasoning retry policy: exactly ONE attempt per call at this layer.
 * The frontend never retries /v1/chat — bounded retries with Retry-After
 * handling live in the backend gateway (one retry max). A 429 here means the
 * shared free-tier budget is spent: surface it, do not re-request it.
 */
export const MAX_REASON_ATTEMPTS = 1;
export class QwenError extends Error {
    fatal;
    kind;
    status;
    constructor(message, fatal, kind, status) {
        super(message);
        this.name = "QwenError";
        this.fatal = fatal;
        this.kind = kind;
        this.status = status;
    }
}
function authHeaders(backend) {
    const headers = { "Content-Type": "application/json" };
    if (backend.token !== undefined && backend.token !== "") {
        headers["Authorization"] = `Bearer ${backend.token}`;
    }
    return headers;
}
/** One reasoning call through the backend. Validated twice (both sides). */
export async function reasonOnce(input) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), input.timeoutMs ?? 45000);
    // User cancellation composes with the timeout: either aborts the fetch.
    const onExternalAbort = () => controller.abort();
    input.signal?.addEventListener("abort", onExternalAbort, { once: true });
    const turnId = input.turnId ?? "no-turn";
    // Payload CONTENT is never logged (page text + user intent); length proves a
    // real reasoning call was made without leaking either.
    logger.info("api: chat attempt", {
        turnId,
        requestType: "chat",
        timestampMs: Date.now(),
        attempt: 1,
        maxAttempts: MAX_REASON_ATTEMPTS,
        payloadChars: input.userPayload.length,
        ...(input.image !== undefined
            ? { hybridImageBytes: input.image.bytes, hybridImageWidth: input.image.width, hybridImageHeight: input.image.height }
            : {}),
    });
    let res;
    try {
        res = await (input.fetchImpl ?? fetch)(`${input.backend.url}${ENDPOINTS.chat}`, {
            method: "POST",
            headers: authHeaders(input.backend),
            body: JSON.stringify({
                userPayload: input.userPayload,
                ...(input.systemPrompt !== undefined ? { systemPrompt: input.systemPrompt } : {}),
                ...(input.effort !== undefined ? { effort: input.effort } : {}),
                ...(input.maxCompletionTokens !== undefined
                    ? { maxCompletionTokens: input.maxCompletionTokens }
                    : {}),
                ...(input.turnId !== undefined ? { turnId: input.turnId } : {}),
                ...(input.image !== undefined ? { image: input.image } : {}),
            }),
            signal: controller.signal,
        });
    }
    catch (err) {
        logger.warn("api: chat failed", {
            turnId,
            requestType: "chat",
            timestampMs: Date.now(),
            attempt: 1,
            outcome: "transport-error",
        });
        void err;
        throw new QwenError("reasoning transport failed", false, "transport");
    }
    finally {
        clearTimeout(timeout);
        input.signal?.removeEventListener("abort", onExternalAbort);
    }
    if (res.status === 429) {
        // Shared budget spent: surface, do not re-request. The agent speaks the
        // RATE_LIMITED message and ends the task instead of retrying.
        logger.warn("api: chat rate limited", {
            turnId,
            requestType: "chat",
            timestampMs: Date.now(),
            attempt: 1,
            outcome: "rate-limited",
            httpStatus: 429,
        });
        throw new QwenError("API rate limit reached. Please wait and try again.", false, "rate_limit", 429);
    }
    if (res.status === 401 || res.status === 403) {
        // Permanent credential rejection: never retried.
        logger.warn("api: chat failed", {
            turnId,
            requestType: "chat",
            timestampMs: Date.now(),
            attempt: 1,
            outcome: "auth-error",
            httpStatus: res.status,
        });
        throw new QwenError("backend rejected frontend credentials", true, "auth", res.status);
    }
    if (!res.ok) {
        await res.text().catch(() => "");
        logger.warn("api: chat failed", {
            turnId,
            requestType: "chat",
            timestampMs: Date.now(),
            attempt: 1,
            outcome: "error",
            httpStatus: res.status,
        });
        throw new QwenError(`backend chat failed (HTTP ${res.status})`, true, "server", res.status);
    }
    const data = (await res.json());
    try {
        const outcome = validateModelOutput(data);
        logger.info("api: chat ok", {
            turnId,
            requestType: "chat",
            timestampMs: Date.now(),
            attempt: 1,
            outcome: "ok",
            httpStatus: res.status,
            outcomeType: outcome.type,
        });
        return outcome;
    }
    catch (err) {
        logger.warn("api: chat failed", {
            turnId,
            requestType: "chat",
            timestampMs: Date.now(),
            attempt: 1,
            outcome: "invalid-outcome",
            httpStatus: res.status,
        });
        throw new QwenError(err instanceof ModelOutputError
            ? `backend returned invalid outcome: ${err.message}`
            : "backend returned unreadable outcome", true, "output");
    }
}
export { BackendError };
//# sourceMappingURL=qwen-client.js.map