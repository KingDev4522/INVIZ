/**
 * Layer-B freshness policy (PRD 3 §30). Pure and deterministic — safe on
 * either side of the frontend/backend boundary. The frontend decides WHEN to
 * call /v1/enrich; the backend only executes enrichment.
 */
import { LAYER_B_FRESHNESS_TTL_MS } from "./constants.js";
const MEANINGFUL_TRIGGERS = new Set([
    "route",
    "modal",
    "form-structure",
    "results",
    "counts",
    "busy",
    "root",
    "bfcache",
]);
/**
 * Should Layer B be (re)built for this trigger? Minor churn never qualifies.
 * Meaningful triggers qualify only when there is no usable interpretation:
 * absent, generation-mismatched, or older than the freshness TTL.
 */
export function needsRefresh(trigger, layerB, currentGeneration, nowMs = Date.now()) {
    if (!MEANINGFUL_TRIGGERS.has(trigger))
        return false;
    if (layerB === null)
        return true;
    if (layerB.pageGeneration !== currentGeneration)
        return true;
    if (layerB.interpretation === "")
        return true;
    return nowMs - layerB.producedAt >= LAYER_B_FRESHNESS_TTL_MS;
}
//# sourceMappingURL=refresh-policy.js.map