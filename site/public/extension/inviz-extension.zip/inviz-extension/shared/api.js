/**
 * Frontend↔backend REST contracts (INVIZ architecture split).
 * The single source of truth for the API boundary: endpoint paths, request /
 * response shapes, error codes, the user-payload builder, and shared language
 * types. Both sides import from here; neither side may invent wire shapes.
 * No secrets, no DOM, no provider specifics beyond model identifiers.
 */
export const API_PREFIX = "/v1";
export const ENDPOINTS = {
    chat: `${API_PREFIX}/chat`,
    enrich: `${API_PREFIX}/enrich`,
    transcribe: `${API_PREFIX}/transcribe`,
    tts: `${API_PREFIX}/tts`,
    search: `${API_PREFIX}/search`,
    health: `${API_PREFIX}/health`,
    validation: `${API_PREFIX}/validation`,
};
/** Transport error thrown by frontend backend-clients. */
export class BackendError extends Error {
    status;
    code;
    constructor(status, code, message) {
        super(message);
        this.name = "BackendError";
        this.status = status;
        this.code = code;
    }
}
/**
 * Builds the user message with provenance-labeled sections (PRD 5 §17).
 * Pure string assembly — safe on either side of the boundary.
 */
export function buildUserPayload(input) {
    const sections = [
        `[USER INTENT, lang=${input.lang}]\n${input.intent}`,
        `[VERIFIED PAGE STATE]\n${input.pageText}`,
    ];
    if (input.skills !== undefined && input.skills.trim() !== "") {
        sections.push(`[AVAILABLE SKILLS]\n${input.skills}`);
    }
    if (input.focusText !== undefined && input.focusText !== "") {
        sections.push(`[CURRENT FOCUS]\n${input.focusText}`);
    }
    if (input.verifiedText !== undefined && input.verifiedText !== "") {
        sections.push(`[LAST VERIFIED RESULT]\n${input.verifiedText}`);
    }
    return sections.join("\n\n");
}
// --- POST /v1/tts ------------------------------------------------------------------
export const TTS_MAX_CHARS = 4000;
//# sourceMappingURL=api.js.map