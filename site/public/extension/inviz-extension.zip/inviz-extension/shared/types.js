/**
 * Shared cross-context contracts (PRD 4 §97–103, PRD 6 §5).
 * Every type used across extension contexts has a runtime validator beside it.
 * Compile-time types alone do NOT satisfy the schema-validation invariant (PRD 5).
 */
export const ACTION_TYPES = [
    "click",
    "type",
    "focus",
    "select",
    "scroll",
    "press_key",
    "navigate",
    "go_back",
    "go_forward",
    "open_tab",
    "close_tab",
    "read",
    "web_search",
    "browser_search",
];
export const EXPECTATION_TYPES = [
    "element_present",
    "element_absent",
    "focused_element",
    "url_changed",
    "dialog_present",
    "text_present",
    "field_value_present",
    "navigation_completed",
    "element_state",
    "submit_completed",
];
/**
 * Skill-id grammar and input bounds, enforced at the model boundary. The model
 * may only name a syntactically valid id; whether that id is registered,
 * executable, and resolvable is decided by the Skill Registry downstream.
 */
export const SKILL_ID_RE = /^[a-z][a-z0-9_]{0,63}$/;
export const SKILL_INPUT_MAX_KEYS = 16;
export const SKILL_INPUT_VALUE_MAX_CHARS = 500;
// ---------------------------------------------------------------------------
// Runtime validators (PRD 6 §5 parameter rules, enforced again by WebGuard)
// ---------------------------------------------------------------------------
const ELEMENT_ID_RE = /^e\d+$/;
/**
 * Readable-prose region handle (r1, r2, …) as advertised in the serialized
 * page's PROSE section. Accepted ONLY by the read action: a region is body
 * text, not a control, so no side-effecting action may target one. Both forms
 * remain opaque handles minted by the frontend — never selectors or URLs.
 */
const PROSE_ID_RE = /^r\d+$/;
const PRESS_KEY_ALLOWLIST = [
    "Enter",
    "Tab",
    "Escape",
    "Space",
    "Backspace",
    "Delete",
    "ArrowUp",
    "ArrowDown",
    "ArrowLeft",
    "ArrowRight",
    "Home",
    "End",
    "PageUp",
    "PageDown",
];
const NAVIGATE_DENIED_SCHEMES = [
    "javascript:",
    "data:",
    "file:",
    "view-source:",
    "chrome:",
    "chrome-extension:",
    "about:",
];
function isRecord(v) {
    return typeof v === "object" && v !== null && !Array.isArray(v);
}
export function isExtensionMessage(v) {
    if (!isRecord(v))
        return false;
    return (typeof v["type"] === "string" &&
        v["type"].length > 0 &&
        typeof v["requestId"] === "string" &&
        v["requestId"].length > 0 &&
        (v["taskId"] === undefined || typeof v["taskId"] === "string") &&
        (v["tabId"] === undefined || Number.isInteger(v["tabId"])) &&
        isRecord(v["payload"]) &&
        (v["timestamp"] === undefined || typeof v["timestamp"] === "number"));
}
/**
 * Expectation vocabulary variants the model reaches for in practice.
 * Measured live: it emits `value_present` for "the field now holds something",
 * which is the `field_value_present` we already implement. Rejecting it failed
 * the whole turn with "unknown expectation type", so the variant is normalized
 * instead. Verification of a field's contents stays boolean-only — the engine
 * asks "is it non-empty", never "what is it" (PRD 5 §17).
 */
const EXPECTATION_ALIASES = {
    value_present: "field_value_present",
    has_value: "field_value_present",
    element_clicked: "element_present",
    clicked: "element_present",
    changed: "element_state",
    content_changed: "url_changed",
    loaded: "navigation_completed",
    // Submit-style side effects have no single observable element to wait for
    // (they navigate, toast, or swap the form), so the model reaching for a
    // generic "did it go through" maps onto the multi-signal expectation.
    submitted: "submit_completed",
    success: "submit_completed",
    done: "submit_completed",
};
function normalizeExpectationType(raw) {
    return EXPECTATION_ALIASES[raw] ?? raw;
}
function validateExpectation(e, path, errors) {
    if (!isRecord(e)) {
        errors.push(path + ": expect must be an object");
        return;
    }
    const rawType = typeof e["type"] === "string" ? e["type"] : null;
    const type = rawType === null ? null : normalizeExpectationType(rawType);
    if (type === null ||
        !EXPECTATION_TYPES.includes(type)) {
        errors.push(path +
            ".type: unknown expectation type" +
            (rawType === null ? "" : ` ("${rawType}")`));
    }
    if (e["target"] !== undefined) {
        if (typeof e["target"] !== "string" || !ELEMENT_ID_RE.test(e["target"])) {
            errors.push(path + ".target: must match eNN");
        }
    }
    if (type === "element_state") {
        const kinds = ["checked", "expanded", "selected", "pressed"];
        if (typeof e["state"] !== "string" || !kinds.includes(e["state"])) {
            errors.push(path + ".state: required for element_state");
        }
        if (typeof e["stateValue"] !== "boolean") {
            errors.push(path + ".stateValue: required boolean for element_state");
        }
    }
}
/**
 * Validates a proposed structured action (shared pre-check).
 * The schema is CLOSED: unknown top-level fields are rejected, so smuggled
 * payloads (run/script/eval/…) can never ride alongside a valid action
 * (PRD 4 §79). WebGuard re-validates with registry + policy context.
 */
export function validateStructuredAction(v) {
    const errors = [];
    if (!isRecord(v))
        return { ok: false, errors: ["action: must be an object"] };
    const KNOWN_FIELDS = [
        "action",
        "target",
        "pageGeneration",
        "value",
        "parameters",
        "expect",
        "timeout_ms",
    ];
    for (const key of Object.keys(v)) {
        if (!KNOWN_FIELDS.includes(key)) {
            errors.push(`unexpected field: ${key}`);
        }
    }
    if (errors.length > 0)
        return { ok: false, errors };
    if (typeof v["action"] !== "string" ||
        !ACTION_TYPES.includes(v["action"])) {
        errors.push("action: unknown action type");
        return { ok: false, errors };
    }
    const action = v["action"];
    const needsTarget = [
        "click",
        "type",
        "focus",
        "select",
        "scroll",
        "press_key",
        "read",
    ];
    if (needsTarget.includes(action)) {
        const target = v["target"];
        if (typeof target !== "string") {
            errors.push("target: required, must match eNN");
        }
        else if (action === "read" && PROSE_ID_RE.test(target)) {
            // Prose region handle — valid for reading body text only.
        }
        else if (!ELEMENT_ID_RE.test(target)) {
            errors.push(action === "read"
                ? "target: required, must match eNN or a prose region id (rNN)"
                : "target: required, must match eNN");
        }
    }
    if (v["pageGeneration"] !== undefined &&
        (!Number.isInteger(v["pageGeneration"]) || v["pageGeneration"] < 0)) {
        errors.push("pageGeneration: must be a non-negative integer");
    }
    if (v["timeout_ms"] !== undefined &&
        (!Number.isInteger(v["timeout_ms"]) ||
            v["timeout_ms"] < 100 ||
            v["timeout_ms"] > 10000)) {
        errors.push("timeout_ms: must be an integer in [100, 10000]");
    }
    if (action === "type") {
        if (typeof v["value"] !== "string") {
            errors.push("value: required string for type");
        }
        else if (v["value"].length > 2000) {
            errors.push("value: exceeds 2000 characters");
        }
    }
    if (action === "select") {
        const p = v["parameters"];
        if (!isRecord(p) || !isRecord(p["option"])) {
            errors.push("parameters.option: required for select");
        }
        else {
            const by = p["option"]["by"];
            const ref = p["option"]["ref"];
            if (by !== "label" && by !== "value" && by !== "index") {
                errors.push("parameters.option.by: must be label|value|index");
            }
            if (typeof ref !== "string" && typeof ref !== "number") {
                errors.push("parameters.option.ref: must be string|number");
            }
        }
    }
    if (action === "press_key") {
        const p = v["parameters"];
        const key = isRecord(p) ? p["key"] : undefined;
        if (typeof key !== "string" || !PRESS_KEY_ALLOWLIST.includes(key)) {
            errors.push("parameters.key: not in the allowlist");
        }
        const modifiers = isRecord(p) ? p["modifiers"] : undefined;
        if (modifiers !== undefined) {
            errors.push("parameters.modifiers: denied by default policy");
        }
    }
    if (action === "navigate" || action === "open_tab") {
        // Destination lives in parameters.url (PRD 4 §100) — never top-level,
        // never a target ID: URLs are data, element references are identity.
        const params = isRecord(v["parameters"]) ? v["parameters"] : undefined;
        const url = params !== undefined ? params["url"] : undefined;
        if (typeof url !== "string") {
            errors.push("parameters.url: required string for " + action);
        }
        else {
            const lowered = url.trim().toLowerCase();
            if (!lowered.startsWith("http://") &&
                !lowered.startsWith("https://")) {
                errors.push("url: only http/https navigation is permitted");
            }
            for (const scheme of NAVIGATE_DENIED_SCHEMES) {
                if (lowered.startsWith(scheme)) {
                    errors.push("url: denied scheme " + scheme);
                    break;
                }
            }
        }
    }
    if (action === "read") {
        const maxChars = isRecord(v["parameters"]) &&
            typeof v["parameters"]["max_chars"] === "number"
            ? v["parameters"]["max_chars"]
            : 4000;
        if (!Number.isInteger(maxChars) || maxChars < 100 || maxChars > 20000) {
            errors.push("parameters.max_chars: must be an integer in [100, 20000]");
        }
    }
    if (action === "web_search") {
        // Query-only, targetless by design (URLs are data, never identity).
        // Results return as verified observations; the model then navigates with
        // the existing navigate/open_tab actions.
        const params = isRecord(v["parameters"]) ? v["parameters"] : undefined;
        const query = params !== undefined ? params["query"] : undefined;
        if (typeof query !== "string" || query.trim() === "") {
            errors.push("parameters.query: required non-empty string for web_search");
        }
        else if (query.length > 400) {
            errors.push("parameters.query: exceeds 400 characters");
        }
        if (v["target"] !== undefined) {
            errors.push("target: web_search takes no target");
        }
    }
    if (action === "browser_search") {
        // PRD 6.10 §6: first-class browser-level search (Chrome default engine).
        // Query-only, targetless like web_search. The controller owns query
        // construction and the executor owns engine navigation — the model never
        // invents a search URL (existing NEVER-invent-URLs rule still applies).
        const params = isRecord(v["parameters"]) ? v["parameters"] : undefined;
        const query = params !== undefined ? params["query"] : undefined;
        if (typeof query !== "string" || query.trim() === "") {
            errors.push("parameters.query: required non-empty string for browser_search");
        }
        else if (query.length > 400) {
            errors.push("parameters.query: exceeds 400 characters");
        }
        if (v["target"] !== undefined) {
            errors.push("target: browser_search takes no target");
        }
    }
    // read is verification-exempt (PRD 6 §5); close_tab verifies by tab-removal
    // event. When expect is present on any other action, it must be valid.
    if (action !== "read" && action !== "close_tab" && v["expect"] !== undefined) {
        validateExpectation(v["expect"], "expect", errors);
    }
    return { ok: errors.length === 0, errors };
}
//# sourceMappingURL=types.js.map