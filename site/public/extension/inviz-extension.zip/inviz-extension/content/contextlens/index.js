/**
 * ContextLens orchestrator — REAL (PRD 6.1).
 * Builds the Raw Page State (Layer A foundation) from live DOM:
 * identity → interactive registry → structure → skipped-region accounting.
 * AI semantic state (Layer B) is filled by Phase 4 enrichment.
 */
import { collectInteractives, extractStates, getForms, getHeadings, getLandmarks, getOpenDialogs, getProseRegions, resolveProseRegionFor, resolveRole, } from "../dom-extractor.js";
import { classifyField, computeAccessibleName, } from "../aria-extractor.js";
import { ElementRegistry } from "../element-registry.js";
export class ContextLens {
    registry = new ElementRegistry();
    elementToId = new Map();
    lastProse = [];
    /** Full extraction + registry rebuild. Returns the new generation. */
    extract(doc = document) {
        const { items, skippedHidden, shadowPierced } = collectInteractives(doc);
        const regItems = items.map((element) => {
            const role = resolveRole(element);
            const { name } = computeAccessibleName(element, doc);
            const states = extractStates(element, role);
            const field = classifyField(element);
            return { element, role, name, states, field };
        });
        const generation = this.registry.rebuild(regItems);
        this.elementToId = new Map();
        for (const entry of this.registry.snapshot()) {
            const live = regItems.find((_, index) => `e${index + 1}` === entry.id)
                ?.element;
            if (live !== undefined)
                this.elementToId.set(live, entry.id);
        }
        this.lastProse = getProseRegions(doc);
        let frames = 0;
        doc.querySelectorAll("iframe,frame,embed,object").forEach(() => {
            frames += 1;
        });
        return {
            url: location.href,
            title: doc.title,
            generation,
            elementCount: regItems.length,
            structure: {
                headings: getHeadings(doc),
                landmarks: getLandmarks(doc),
                forms: getForms(doc),
                openDialogs: getOpenDialogs(doc).length,
            },
            prose: this.lastProse,
            skipped: { hidden: skippedHidden, frames, shadow: shadowPierced },
            extractedAt: Date.now(),
        };
    }
    /** Registry identity for a live element (announcement/executor use). */
    identify(el) {
        return {
            elementId: this.elementToId.get(el) ?? null,
            generation: this.registry.currentGeneration,
        };
    }
    /**
     * Readable container for an element. A heading maps to the article body it
     * introduces, so "read this" on an <h1> yields the article rather than the
     * headline. Falls back to the element itself when no prose region matches.
     */
    proseFor(el) {
        return resolveProseRegionFor(el) ?? el;
    }
    /** Prose regions captured by the most recent extract(). */
    proseRegions() {
        return this.lastProse;
    }
}
//# sourceMappingURL=index.js.map