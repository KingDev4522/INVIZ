"use strict";
(() => {
  // ../shared/redact.ts
  var CARD_RE = /\b(?:\d[ -]?){13,19}\b/g;
  var SECRET_WORDS = /* @__PURE__ */ new Set([
    "password",
    "passwd",
    "otp",
    "cvv",
    "card",
    "cardnumber",
    "secret",
    "token",
    "tokens",
    "key",
    "keys",
    "apikey",
    "authtoken",
    "authorization",
    "credential",
    "credentials"
  ]);
  var SAFE_SUFFIXES = [
    "configured",
    "count",
    "present",
    "enabled",
    "status",
    "ok",
    "mode",
    "length",
    "size",
    "expiry",
    "time",
    "at",
    "date"
  ];
  function isSensitiveKey(key) {
    const lower = key.toLowerCase();
    if (SAFE_SUFFIXES.some((suffix) => lower.endsWith(suffix))) return false;
    const segments = key.replace(/([a-z0-9])([A-Z])/g, "$1 $2").split(/[^A-Za-z]+/).filter((s) => s !== "");
    return segments.some((s) => SECRET_WORDS.has(s.toLowerCase()));
  }
  var REDACTED = "[REDACTED]";
  function redactString(input) {
    return input.replace(CARD_RE, (m) => {
      const digits = m.replace(/[ -]/g, "");
      if (digits.length >= 13 && digits.length <= 19 && /^\d+$/.test(digits)) {
        return REDACTED;
      }
      return m;
    });
  }
  function redactObject(value) {
    if (typeof value === "string") return redactString(value);
    if (Array.isArray(value)) {
      return value.map((v) => redactObject(v));
    }
    if (typeof value === "object" && value !== null) {
      const out = {};
      for (const [k, v] of Object.entries(value)) {
        out[k] = isSensitiveKey(k) ? REDACTED : redactObject(v);
      }
      return out;
    }
    return value;
  }

  // ../shared/logger.ts
  var LEVEL_ORDER = {
    debug: 0,
    info: 1,
    warn: 2,
    error: 3
  };
  var currentLevel = "info";
  function emit(level, message, meta) {
    if (LEVEL_ORDER[level] < LEVEL_ORDER[currentLevel]) return;
    const safeMeta = meta === void 0 ? void 0 : redactObject(meta);
    const line = { level, message, ...safeMeta ? { meta: safeMeta } : {} };
    if (level === "error") {
      console.error(JSON.stringify(line));
    } else if (level === "warn") {
      console.warn(JSON.stringify(line));
    } else {
      console.log(JSON.stringify(line));
    }
  }
  var logger = {
    debug: (message, meta) => emit("debug", message, meta),
    info: (message, meta) => emit("info", message, meta),
    warn: (message, meta) => emit("warn", message, meta),
    error: (message, meta) => emit("error", message, meta)
  };

  // ../shared/types.ts
  function isRecord(v) {
    return typeof v === "object" && v !== null && !Array.isArray(v);
  }
  function isExtensionMessage(v) {
    if (!isRecord(v)) return false;
    return typeof v["type"] === "string" && v["type"].length > 0 && typeof v["requestId"] === "string" && v["requestId"].length > 0 && (v["taskId"] === void 0 || typeof v["taskId"] === "string") && (v["tabId"] === void 0 || Number.isInteger(v["tabId"])) && isRecord(v["payload"]) && (v["timestamp"] === void 0 || typeof v["timestamp"] === "number");
  }

  // src/content/focus-monitor.ts
  var ROLE_LABELS = {
    button: { en: "Button", hi: "\u092C\u091F\u0928" },
    link: { en: "Link", hi: "\u0932\u093F\u0902\u0915" },
    textbox: { en: "Edit box", hi: "\u090F\u0921\u093F\u091F \u092C\u0949\u0915\u094D\u0938" },
    searchbox: { en: "Search box", hi: "\u0916\u094B\u091C \u092C\u0949\u0915\u094D\u0938" },
    combobox: { en: "Combo box", hi: "\u0915\u0949\u092E\u094D\u092C\u094B \u092C\u0949\u0915\u094D\u0938" },
    checkbox: { en: "Checkbox", hi: "\u091A\u0947\u0915\u092C\u0949\u0915\u094D\u0938" },
    radio: { en: "Radio button", hi: "\u0930\u0947\u0921\u093F\u092F\u094B \u092C\u091F\u0928" },
    select: { en: "Drop-down", hi: "\u0921\u094D\u0930\u0949\u092A-\u0921\u093E\u0909\u0928" },
    textarea: { en: "Text area", hi: "\u091F\u0947\u0915\u094D\u0938\u094D\u091F \u0915\u094D\u0937\u0947\u0924\u094D\u0930" },
    heading: { en: "Heading", hi: "\u0936\u0940\u0930\u094D\u0937\u0915" },
    dialog: { en: "Dialog", hi: "\u0938\u0902\u0935\u093E\u0926" },
    menuitem: { en: "Menu item", hi: "\u092E\u0947\u0928\u0942 \u0906\u0907\u091F\u092E" },
    tab: { en: "Tab", hi: "\u091F\u0948\u092C" },
    slider: { en: "Slider", hi: "\u0938\u094D\u0932\u093E\u0907\u0921\u0930" },
    switch: { en: "Switch", hi: "\u0938\u094D\u0935\u093F\u091A" },
    img: { en: "Image", hi: "\u091A\u093F\u0924\u094D\u0930" },
    list: { en: "List", hi: "\u0938\u0942\u091A\u0940" },
    navigation: { en: "Navigation", hi: "\u0928\u0947\u0935\u093F\u0917\u0947\u0936\u0928" },
    main: { en: "Main content", hi: "\u092E\u0941\u0916\u094D\u092F \u0938\u093E\u092E\u0917\u094D\u0930\u0940" },
    form: { en: "Form", hi: "\u092B\u093C\u0949\u0930\u094D\u092E" },
    // Hover-only role for readable text blocks (paragraphs, cards). The
    // keyboard path never produces it (generic is excluded before announcement),
    // so adding it cannot change focus narration.
    text: { en: "Text", hi: "\u092A\u093E\u0920" }
  };
  var HINTS = {
    searchbox: {
      en: () => "Type your search query.",
      hi: () => "\u0905\u092A\u0928\u0940 \u0916\u094B\u091C \u0932\u093F\u0916\u0947\u0902\u0964"
    },
    "button:submit": {
      en: (name) => `Activates ${name}.`,
      hi: (name) => `${name} \u0938\u0915\u094D\u0930\u093F\u092F \u0915\u0930\u0924\u093E \u0939\u0948\u0964`
    }
  };
  function roleLabel(role, lang) {
    const entry = ROLE_LABELS[role];
    if (entry === void 0) return role;
    return lang === "hi" ? entry.hi : entry.en;
  }
  function stateBits(states, lang) {
    const bits = [];
    if (states["checked"] === true) bits.push(lang === "hi" ? "\u091A\u092F\u0928\u093F\u0924" : "checked");
    if (states["checked"] === false && "checked" in states) {
      bits.push(lang === "hi" ? "\u0905\u091A\u092F\u0928\u093F\u0924" : "not checked");
    }
    if (states["expanded"] === true) bits.push(lang === "hi" ? "\u0916\u0941\u0932\u093E" : "expanded");
    if (states["expanded"] === false && "expanded" in states) {
      bits.push(lang === "hi" ? "\u092C\u0902\u0926" : "collapsed");
    }
    if (states["selected"] === true) bits.push(lang === "hi" ? "\u091A\u092F\u0928\u093F\u0924" : "selected");
    if (states["pressed"] === true) bits.push(lang === "hi" ? "\u0926\u092C\u093E \u0939\u0941\u0906" : "pressed");
    if (states["required"] === true) bits.push(lang === "hi" ? "\u0906\u0935\u0936\u094D\u092F\u0915" : "required");
    if (states["invalid"] === true || states["invalid"] === "true") {
      bits.push(lang === "hi" ? "\u0905\u092E\u093E\u0928\u094D\u092F" : "invalid");
    }
    if (states["disabled"] === true) bits.push(lang === "hi" ? "\u0905\u0915\u094D\u0937\u092E" : "disabled");
    if (typeof states["level"] === "number") {
      bits.push(lang === "hi" ? `\u0938\u094D\u0924\u0930 ${states["level"]}` : `level ${states["level"]}`);
    }
    return bits;
  }
  function hintFor(role, el, name, lang, verbosity) {
    if (verbosity === "terse") return "";
    if (role === "searchbox") {
      return lang === "hi" ? HINTS["searchbox"]?.hi(name) ?? "" : HINTS["searchbox"]?.en(name) ?? "";
    }
    if (role === "button" && el instanceof HTMLButtonElement && el.type === "submit") {
      const key = "button:submit";
      return lang === "hi" ? HINTS[key]?.hi(name) ?? "" : HINTS[key]?.en(name) ?? "";
    }
    if (role === "button" && el instanceof HTMLInputElement && el.type === "submit") {
      const key = "button:submit";
      return lang === "hi" ? HINTS[key]?.hi(name) ?? "" : HINTS[key]?.en(name) ?? "";
    }
    return "";
  }
  function buildAnnouncement(input) {
    const label = roleLabel(input.role, input.lang);
    const bits = stateBits(input.states, input.lang);
    const hint = hintFor(input.role, input.element, input.name, input.lang, input.verbosity);
    const displayName = input.name !== "" ? input.name : label;
    const parts = [displayName, label, ...bits];
    if (hint !== "") parts.push(hint);
    const text = input.verbosity === "terse" ? displayName : input.lang === "hi" ? parts.join(" ") : parts.map((p) => p.replace(/\.$/, "")).join(". ") + ".";
    const signature = [input.elementId, input.name, input.role, bits.join("|"), hint].join("~");
    return {
      elementId: input.elementId,
      name: input.name,
      role: input.role,
      stateBits: bits,
      hint,
      lang: input.lang,
      text,
      signature
    };
  }
  function isAnnounceableTarget(el, role, name) {
    if (role === "generic" || role === "none" || role === "presentation") return false;
    if (name.trim() === "") return false;
    return isMeaningfulFocusTarget(el, role);
  }
  function isMeaningfulFocusTarget(el, role) {
    if (role === "generic" || role === "none" || role === "presentation") return false;
    const focusable = el.tabIndex >= 0 || isNativelyFocusableTag(el);
    return focusable;
  }
  function isSiteBranding(el, role, name) {
    if (role !== "link" && role !== "img") return false;
    const inBanner = el.closest("header, [role='banner']") !== null;
    if (!inBanner) return false;
    if (el.tagName.toLowerCase() === "img") return true;
    if (el.querySelector("img, svg") !== null) return true;
    const href = el.getAttribute("href");
    if (href === "/" || href === "" || href === "#") return true;
    return name.trim() !== "" && el.textContent?.trim() === name.trim() && href === "/";
  }
  function isNativelyFocusableTag(el) {
    const tag = el.tagName.toLowerCase();
    if (tag === "a") return el.hasAttribute("href");
    return tag === "button" || tag === "input" || tag === "select" || tag === "textarea" || tag === "summary" || tag === "area";
  }
  var HOVER_TEXT_MAX_CHARS = 200;
  var HOVER_CLIMB_MAX = 4;
  var HOVER_SKIP_SELECTOR = "script,style,noscript,template,option,select";
  function collapseHoverText(value) {
    return value.replace(/\s+/g, " ").trim();
  }
  function hoverTextOf(el) {
    const tag = el.tagName.toLowerCase();
    if (tag === "html" || tag === "body") return "";
    if (el.closest(HOVER_SKIP_SELECTOR) !== null) return "";
    if (el.hasAttribute("hidden") || el.getAttribute("aria-hidden") === "true") return "";
    return collapseHoverText(el.textContent ?? "").slice(0, HOVER_TEXT_MAX_CHARS);
  }
  function resolveHoverTarget(el, role, name) {
    const structural = role === "generic" || role === "none" || role === "presentation";
    if (!structural && name.trim() !== "") {
      return { element: el, name: name.trim().slice(0, HOVER_TEXT_MAX_CHARS), role };
    }
    let node = el;
    for (let level = 0; level <= HOVER_CLIMB_MAX && node !== null; level += 1) {
      const text = hoverTextOf(node);
      if (text !== "") return { element: node, name: text, role: "text" };
      node = node.parentElement;
    }
    return null;
  }
  function isDescendantComposed(ancestor, node) {
    let current = node;
    while (current !== null) {
      if (current === ancestor) return true;
      const root = current.getRootNode();
      current = root instanceof ShadowRoot ? root.host : current.parentElement;
    }
    return false;
  }
  var SYSTEM_HOVER_CLOCK = {
    now: () => Date.now(),
    schedule: (fn, ms) => {
      setTimeout(fn, ms);
    }
  };
  var HoverCoalescer = class {
    constructor(process, clock = SYSTEM_HOVER_CLOCK, immediateMs = 600, settleMs = 250) {
      this.process = process;
      this.clock = clock;
      this.immediateMs = immediateMs;
      this.settleMs = settleMs;
    }
    process;
    clock;
    immediateMs;
    settleMs;
    pending = null;
    lastProcessAt = 0;
    scheduled = false;
    push(el) {
      this.pending = el;
      if (this.clock.now() - this.lastProcessAt >= this.immediateMs) {
        this.flush();
        return;
      }
      if (this.scheduled) return;
      this.scheduled = true;
      this.clock.schedule(() => {
        this.scheduled = false;
        this.flush();
      }, this.settleMs);
    }
    flush() {
      const el = this.pending;
      this.pending = null;
      if (el === null) return;
      this.lastProcessAt = this.clock.now();
      this.process(el);
    }
  };
  var FocusMonitor = class {
    constructor(resolve) {
      this.resolve = resolve;
    }
    resolve;
    lastSignature = null;
    listeners = /* @__PURE__ */ new Set();
    lang = "en";
    verbosity = "terse";
    boundHandler = null;
    setLang(lang) {
      this.lang = lang;
      this.lastSignature = null;
    }
    setVerbosity(v) {
      this.verbosity = v;
      this.lastSignature = null;
    }
    onAnnouncement(cb) {
      this.listeners.add(cb);
      return () => {
        this.listeners.delete(cb);
      };
    }
    /** Testable entry point: process one focused element. */
    handleFocus(el) {
      const resolved = this.resolve(el);
      if (resolved === null) return null;
      if (isSiteBranding(el, resolved.role, resolved.name)) return null;
      if (!isAnnounceableTarget(el, resolved.role, resolved.name)) return null;
      const announcement = buildAnnouncement({
        elementId: resolved.elementId,
        name: resolved.name,
        role: resolved.role,
        states: resolved.states,
        element: el,
        lang: this.lang,
        verbosity: this.verbosity
      });
      if (announcement.signature === this.lastSignature) return null;
      this.lastSignature = announcement.signature;
      this.listeners.forEach((cb) => cb(announcement));
      return announcement;
    }
    /**
     * Cursor-aware entry point: process one hovered element.
     *
     * Unlike handleFocus, keyboard focusability is NOT required — the cursor is
     * already on the content, so headings, plain text, images with alt text and
     * readable containers are all legitimate narration targets. Brand/chrome
     * suppression, empty-content silence and cross-announcement dedupe are kept.
     */
    handleHover(el) {
      const resolved = this.resolve(el);
      if (resolved === null) return null;
      if (isSiteBranding(el, resolved.role, resolved.name)) return null;
      const target = resolveHoverTarget(el, resolved.role, resolved.name);
      if (target === null) return null;
      const announcement = buildAnnouncement({
        elementId: resolved.elementId,
        name: target.name,
        role: target.role,
        states: resolved.states,
        element: target.element,
        lang: this.lang,
        verbosity: this.verbosity
      });
      if (announcement.signature === this.lastSignature) return null;
      this.lastSignature = announcement.signature;
      this.listeners.forEach((cb) => cb(announcement));
      return announcement;
    }
    start() {
      if (this.boundHandler !== null) return;
      this.boundHandler = (e) => {
        const target = e.target;
        if (target instanceof Element) this.handleFocus(target);
      };
      document.addEventListener("focusin", this.boundHandler, true);
    }
    stop() {
      if (this.boundHandler === null) return;
      document.removeEventListener("focusin", this.boundHandler, true);
      this.boundHandler = null;
    }
  };

  // src/content/dom-extractor.ts
  var KNOWN_ROLES = /* @__PURE__ */ new Set([
    "button",
    "link",
    "textbox",
    "searchbox",
    "combobox",
    "listbox",
    "checkbox",
    "radio",
    "switch",
    "slider",
    "spinbutton",
    "select",
    "textarea",
    "heading",
    "navigation",
    "main",
    "complementary",
    "contentinfo",
    "banner",
    "form",
    "dialog",
    "alertdialog",
    "menu",
    "menubar",
    "menuitem",
    "menuitemcheckbox",
    "menuitemradio",
    "tab",
    "tablist",
    "tabpanel",
    "list",
    "listitem",
    "table",
    "row",
    "cell",
    "columnheader",
    "rowheader",
    "img",
    "progressbar",
    "status",
    "alert",
    "article",
    "region",
    "search",
    "separator",
    "toolbar",
    "tooltip",
    "tree",
    "treeitem",
    "grid",
    "gridcell",
    "option",
    "radiogroup",
    "group",
    "generic"
  ]);
  var WIDGET_ROLES = /* @__PURE__ */ new Set([
    "button",
    "link",
    "textbox",
    "searchbox",
    "combobox",
    "listbox",
    "checkbox",
    "radio",
    "switch",
    "slider",
    "spinbutton",
    "select",
    "textarea",
    "menuitem",
    "menuitemcheckbox",
    "menuitemradio",
    "tab",
    "treeitem",
    "option",
    "progressbar",
    "img"
  ]);
  function implicitRole(el) {
    const tag = el.tagName.toLowerCase();
    switch (tag) {
      case "a":
        return el.hasAttribute("href") ? "link" : "generic";
      case "button":
        return "button";
      case "select":
        return "combobox";
      case "textarea":
        return "textbox";
      case "summary":
        return "button";
      case "dialog":
        return "dialog";
      case "nav":
        return "navigation";
      case "main":
        return "main";
      case "header":
        return "banner";
      case "footer":
        return "contentinfo";
      case "aside":
        return "complementary";
      case "ul":
      case "ol":
        return "list";
      case "li":
        return "listitem";
      case "table":
        return "table";
      case "tr":
        return "row";
      case "td":
        return "cell";
      case "th":
        return "columnheader";
      case "img":
        return el.getAttribute("alt") === null ? "presentation" : "img";
      case "progress":
        return "progressbar";
      case "form":
        return "form";
      case "h1":
      case "h2":
      case "h3":
      case "h4":
      case "h5":
      case "h6":
        return "heading";
      case "input": {
        const type = (el.getAttribute("type") ?? "text").toLowerCase();
        switch (type) {
          case "button":
          case "submit":
          case "reset":
          case "image":
            return "button";
          case "checkbox":
            return "checkbox";
          case "radio":
            return "radio";
          case "search":
            return "searchbox";
          case "number":
          case "range":
            return type === "range" ? "slider" : "spinbutton";
          case "hidden":
            return "none";
          default:
            return "textbox";
        }
      }
      default:
        return "generic";
    }
  }
  function resolveRole(el) {
    const explicit = el.getAttribute("role")?.trim().split(/\s+/)[0]?.toLowerCase();
    if (explicit !== void 0 && explicit !== "" && KNOWN_ROLES.has(explicit)) {
      return explicit;
    }
    return implicitRole(el);
  }
  function isVisible(el) {
    if (el.hasAttribute("hidden")) return false;
    if (el.getAttribute("aria-hidden") === "true") return false;
    try {
      const cs = getComputedStyle(el);
      if (cs.display === "none" || cs.visibility === "hidden") return false;
    } catch {
    }
    return true;
  }
  function readAriaState(states, el, attr, key) {
    const v = el.getAttribute(attr);
    if (v === null) return;
    if (v === "true") states[key] = true;
    else if (v === "false") states[key] = false;
    else states[key] = v;
  }
  function extractStates(el, role) {
    const states = {};
    readAriaState(states, el, "aria-checked", "checked");
    readAriaState(states, el, "aria-selected", "selected");
    readAriaState(states, el, "aria-expanded", "expanded");
    readAriaState(states, el, "aria-pressed", "pressed");
    readAriaState(states, el, "aria-required", "required");
    readAriaState(states, el, "aria-invalid", "invalid");
    readAriaState(states, el, "aria-readonly", "readonly");
    readAriaState(states, el, "aria-disabled", "disabled");
    readAriaState(states, el, "aria-level", "level");
    readAriaState(states, el, "aria-valuenow", "value");
    if (el instanceof HTMLInputElement) {
      if (el.type === "checkbox" || el.type === "radio") states["checked"] = el.checked;
      if (el.disabled) states["disabled"] = true;
      if (el.required) states["required"] = true;
      if (el.readOnly) states["readonly"] = true;
    }
    if (el instanceof HTMLSelectElement || el instanceof HTMLTextAreaElement) {
      if (el.disabled) states["disabled"] = true;
      if (el.required) states["required"] = true;
    }
    if (el instanceof HTMLButtonElement && el.disabled) states["disabled"] = true;
    if (role === "heading") {
      const m = /^h([1-6])$/.exec(el.tagName.toLowerCase());
      if (m?.[1] !== void 0) states["level"] = Number(m[1]);
      else if (states["level"] === void 0) states["level"] = 2;
    }
    if (el instanceof HTMLDialogElement) states["open"] = el.open;
    if (el.tagName.toLowerCase() === "details") {
      states["expanded"] = el.open;
    }
    return states;
  }
  var INTERACTIVE_SELECTOR = [
    "a[href]",
    "button",
    "input",
    "select",
    "textarea",
    "summary",
    "[tabindex]",
    "[role]",
    "[contenteditable]"
  ].join(",");
  function queryDeep(root, selector, stats) {
    const out = [];
    const seen = /* @__PURE__ */ new Set();
    const walk = (node) => {
      if (seen.has(node)) return;
      seen.add(node);
      node.querySelectorAll(selector).forEach((el) => {
        out.push(el);
      });
      node.querySelectorAll("*").forEach((el) => {
        const shadow = el.shadowRoot ?? null;
        if (shadow !== null) {
          if (stats !== void 0) stats.pierced += 1;
          walk(shadow);
        }
      });
      node.querySelectorAll("iframe,frame").forEach((el) => {
        let inner = null;
        try {
          inner = el.contentDocument ?? null;
        } catch {
          inner = null;
        }
        if (inner !== null) walk(inner);
      });
    };
    walk(root);
    return out;
  }
  function collectInteractives(root) {
    const stats = { pierced: 0 };
    const found = queryDeep(root, INTERACTIVE_SELECTOR, stats);
    const items = [];
    let skippedHidden = 0;
    found.forEach((el) => {
      if (el.tabIndex === -1 && !isNativelyFocusable(el)) {
        return;
      }
      if (!isVisible(el)) {
        skippedHidden += 1;
        return;
      }
      const role = resolveRole(el);
      if (role === "none" || role === "presentation") return;
      if (WIDGET_ROLES.has(role) || isFocusableCandidate(el)) {
        items.push(el);
      }
    });
    return { items, skippedHidden, shadowPierced: stats.pierced };
  }
  function isNativelyFocusable(el) {
    const tag = el.tagName.toLowerCase();
    if (tag === "a") return el.hasAttribute("href");
    if (tag === "button" || tag === "select" || tag === "textarea") return true;
    if (tag === "input") {
      return (el.getAttribute("type") ?? "text").toLowerCase() !== "hidden";
    }
    if (tag === "summary") return true;
    return el.hasAttribute("contenteditable");
  }
  function isFocusableCandidate(el) {
    const tabindex = el.tabIndex;
    if (Number.isInteger(tabindex) && tabindex >= 0) return true;
    return isNativelyFocusable(el);
  }
  var PROSE_SELECTOR = [
    "article",
    "main",
    "[role='article']",
    "[role='main']",
    "[role='document']",
    ".article-body",
    ".post-content",
    ".entry-content",
    "#content"
  ].join(",");
  var PROSE_BLOCK_TAGS = /* @__PURE__ */ new Set([
    "p",
    "li",
    "blockquote",
    "pre",
    "figcaption",
    "dd",
    "dt",
    "td",
    "th"
  ]);
  function isElement(node) {
    return typeof node === "object" && node !== null && typeof node.hasAttribute === "function";
  }
  function isProseNoise(el) {
    if (!isVisible(el)) return true;
    const tag = el.tagName.toLowerCase();
    if (tag === "script" || tag === "style" || tag === "noscript" || tag === "template") {
      return true;
    }
    if (el.getAttribute("aria-hidden") === "true" || el.hasAttribute("hidden")) return true;
    return false;
  }
  function getProseRegions(root, limit = 6) {
    const containers = [];
    const seen = /* @__PURE__ */ new Set();
    queryDeep(root, PROSE_SELECTOR).forEach((el) => {
      if (el.parentElement?.closest(PROSE_SELECTOR) != null) return;
      if (isProseNoise(el)) return;
      containers.push(el);
      seen.add(el);
    });
    if (containers.length === 0 && isElement(root) && isVisible(root)) {
      containers.push(root);
    }
    const regions = [];
    for (const container of containers) {
      if (regions.length >= limit) break;
      const parts = [];
      queryDeep(container, "*").forEach((el) => {
        if (el.children.length > 0 && el.shadowRoot === null) return;
        if (!PROSE_BLOCK_TAGS.has(el.tagName.toLowerCase())) return;
        if (isProseNoise(el)) return;
        const text2 = (el.textContent ?? "").replace(/\s+/g, " ").trim();
        if (text2 !== "") parts.push(text2);
      });
      const text = parts.join(" ").trim();
      if (text === "") continue;
      const heading = queryDeep(container, "h1,h2,h3,[role='heading']")[0]?.textContent?.trim() ?? "";
      regions.push({
        id: `r${regions.length + 1}`,
        label: heading !== "" ? heading.replace(/\s+/g, " ") : container.tagName.toLowerCase(),
        text,
        chars: text.length
      });
    }
    return regions;
  }
  function resolveProseRegionFor(el) {
    const match = el.closest(PROSE_SELECTOR);
    if (match !== null && isVisible(match)) return match;
    let node = el.parentElement;
    while (node !== null) {
      if (isProseNoise(node)) return null;
      if (PROSE_BLOCK_TAGS.has(node.tagName.toLowerCase()) || node.tagName.toLowerCase() === "div") {
        const text = (node.textContent ?? "").replace(/\s+/g, " ").trim();
        if (text.length > 120) return node;
      }
      node = node.parentElement;
    }
    return null;
  }
  function getHeadings(root) {
    const out = [];
    queryDeep(root, "h1,h2,h3,h4,h5,h6,[role='heading']").forEach((el) => {
      if (!isVisible(el)) return;
      const text = (el.textContent ?? "").trim().replace(/\s+/g, " ");
      if (text === "") return;
      const m = /^h([1-6])$/.exec(el.tagName.toLowerCase());
      const level = m?.[1] !== void 0 ? Number(m[1]) : Number(el.getAttribute("aria-level") ?? 2);
      out.push({ level, text: text.slice(0, 200) });
    });
    return out;
  }
  function getLandmarks(root) {
    const out = [];
    queryDeep(
      root,
      "nav,main,header,footer,aside,form,[role='navigation'],[role='main'],[role='complementary'],[role='contentinfo'],[role='banner'],[role='search'],[role='region']"
    ).forEach((el) => {
      if (!isVisible(el)) return;
      out.push({
        role: resolveRole(el),
        name: (el.getAttribute("aria-label") ?? "").slice(0, 120)
      });
    });
    return out;
  }
  function getForms(root) {
    const out = [];
    queryDeep(root, "form").forEach((el) => {
      if (!isVisible(el)) return;
      out.push({
        name: (el.getAttribute("aria-label") ?? el.getAttribute("name") ?? "").slice(0, 120),
        fieldCount: queryDeep(el, "input,select,textarea").length
      });
    });
    return out;
  }
  function getOpenDialogs(root) {
    const out = [];
    queryDeep(root, "dialog[open],[role='dialog'],[role='alertdialog']").forEach((el) => {
      if (isVisible(el)) out.push(el);
    });
    return out;
  }

  // src/content/aria-extractor.ts
  var MAX_DEPTH = 5;
  function collapse(text) {
    return text.trim().replace(/\s+/g, " ");
  }
  function fromLabel(el, doc) {
    const id = el.getAttribute("id");
    if (id !== null && id !== "") {
      try {
        const labelled = doc.querySelector(`label[for="${CSS.escape(id)}"]`);
        const text2 = labelled?.textContent;
        if (text2 !== void 0 && collapse(text2) !== "") {
          return collapse(text2).slice(0, 200);
        }
      } catch {
      }
    }
    const wrapping = el.closest("label");
    const text = wrapping?.textContent;
    if (text !== void 0 && collapse(text) !== "") {
      return collapse(text).slice(0, 200);
    }
    return "";
  }
  function nameFromLabelledBy(el, doc, visited, depth) {
    if (depth > MAX_DEPTH) return "";
    const ref = el.getAttribute("aria-labelledby");
    if (ref === null || ref.trim() === "") return "";
    const parts = [];
    for (const id of ref.trim().split(/\s+/)) {
      if (id === "") continue;
      let target = null;
      try {
        target = doc.getElementById(id);
      } catch {
        continue;
      }
      if (target === null || visited.has(target)) continue;
      visited.add(target);
      const nested = target.getAttribute("aria-labelledby");
      if (nested !== null && nested.trim() !== "") {
        parts.push(nameFromLabelledBy(target, doc, visited, depth + 1));
      } else {
        parts.push(collapse(target.textContent ?? ""));
      }
    }
    return collapse(parts.join(" ")).slice(0, 200);
  }
  function nativeName(el) {
    const tag = el.tagName.toLowerCase();
    if (tag === "img" || tag === "area") {
      return collapse(el.getAttribute("alt") ?? "");
    }
    if (tag === "input") {
      const type = (el.getAttribute("type") ?? "text").toLowerCase();
      if (type === "image") return collapse(el.getAttribute("alt") ?? "");
      if (type === "submit" || type === "button" || type === "reset") {
        const v = el.getAttribute("value");
        return collapse(v ?? (type === "submit" ? "Submit" : type));
      }
    }
    return "";
  }
  function textName(el) {
    const tag = el.tagName.toLowerCase();
    if (tag === "input" || tag === "textarea" || tag === "select" || tag === "img" || tag === "video" || tag === "audio") {
      return "";
    }
    return collapse(el.textContent ?? "").slice(0, 200);
  }
  function computeAccessibleName(el, doc = el.getRootNode() ?? document) {
    const labelled = fromLabel(el, doc);
    if (labelled !== "") return { name: labelled, source: "label" };
    const byIds = nameFromLabelledBy(el, doc, /* @__PURE__ */ new Set([el]), 0);
    if (byIds !== "") return { name: byIds, source: "labelledby" };
    const ariaLabel = collapse(el.getAttribute("aria-label") ?? "");
    if (ariaLabel !== "") {
      return { name: ariaLabel.slice(0, 200), source: "aria-label" };
    }
    const native = nativeName(el);
    if (native !== "") return { name: native, source: "native" };
    const text = textName(el);
    if (text !== "") return { name: text, source: "text" };
    const weak = collapse(
      el.getAttribute("placeholder") ?? el.getAttribute("title") ?? ""
    );
    if (weak !== "") return { name: weak.slice(0, 200), source: "weak" };
    return { name: "", source: "none" };
  }
  var OTP_RE = /otp|one[-_ ]?time|verification[-_ ]?code/i;
  function isOtpField(el) {
    if (el.getAttribute("autocomplete") === "one-time-code") return true;
    const haystack = `${el.getAttribute("name") ?? ""} ${el.getAttribute("id") ?? ""} ${el.getAttribute("aria-label") ?? ""}`;
    return OTP_RE.test(haystack);
  }
  function classifyField(el) {
    const tag = el.tagName.toLowerCase();
    if (tag === "textarea") return { kind: "textarea", sensitive: false };
    if (tag === "select") return { kind: "select", sensitive: false };
    if (tag !== "input") {
      if (el.hasAttribute("contenteditable")) return { kind: "text", sensitive: false };
      return null;
    }
    const type = (el.getAttribute("type") ?? "text").toLowerCase();
    let kind;
    switch (type) {
      case "email":
        kind = "email";
        break;
      case "password":
        kind = "password";
        break;
      case "number":
        kind = "number";
        break;
      case "checkbox":
        kind = "checkbox";
        break;
      case "radio":
        kind = "radio";
        break;
      case "date":
      case "datetime-local":
      case "month":
      case "time":
      case "week":
        kind = "date";
        break;
      case "file":
        kind = "file";
        break;
      case "hidden":
      case "submit":
      case "button":
      case "reset":
      case "image":
        return null;
      default:
        kind = "text";
        break;
    }
    const sensitive = kind === "password" || kind === "file" || isOtpField(el);
    return { kind, sensitive };
  }
  function fieldHasValue(el) {
    if (el instanceof HTMLInputElement) {
      if (el.type === "checkbox" || el.type === "radio") return el.checked;
      return el.value.length > 0;
    }
    if (el instanceof HTMLTextAreaElement) return el.value.length > 0;
    if (el instanceof HTMLSelectElement) return el.selectedIndex >= 0;
    return false;
  }

  // ../shared/constants.ts
  var GROQ_BASE_URL = "https://api.groq.com/openai/v1";
  var GROQ_SPEECH_ENDPOINT = `${GROQ_BASE_URL}/audio/speech`;
  var TTS_AUDIO_CACHE_MAX_BYTES = 50 * 1024 * 1024;
  var PAGE_STATE_TAB_CAP_BYTES = 1 * 1024 * 1024;
  var STORAGE_KEY_CONFIG = "config:user";
  var MAX_EPISODE_BYTES = 32 * 1024;

  // src/content/element-registry.ts
  var ElementRegistry = class {
    generation = 0;
    entries = /* @__PURE__ */ new Map();
    get currentGeneration() {
      return this.generation;
    }
    get size() {
      return this.entries.size;
    }
    /** Rebuilds the registry from a fresh extraction; invalidates all old IDs. */
    rebuild(items) {
      this.generation += 1;
      this.entries.clear();
      items.forEach((item, index) => {
        const id = `e${index + 1}`;
        this.entries.set(id, { ...item, id, generation: this.generation });
      });
      return this.generation;
    }
    resolve(id, generation) {
      if (!/^e\d+$/.test(id)) {
        return { ok: false, code: "ELEMENT_NOT_FOUND" };
      }
      if (generation !== this.generation) {
        return { ok: false, code: "STALE_TARGET" };
      }
      const entry = this.entries.get(id);
      if (entry === void 0) {
        return { ok: false, code: "ELEMENT_NOT_FOUND" };
      }
      if (!entry.element.isConnected) {
        return { ok: false, code: "STALE_TARGET" };
      }
      return { ok: true, entry };
    }
    /** Snapshot metadata for PageState (no live references cross contexts). */
    snapshot() {
      return [...this.entries.values()].map((e) => ({
        id: e.id,
        role: e.role,
        name: e.name,
        states: e.states,
        fieldKind: e.field?.kind ?? null,
        sensitive: e.field?.sensitive ?? false
      }));
    }
  };

  // src/content/contextlens/index.ts
  var ContextLens = class {
    registry = new ElementRegistry();
    elementToId = /* @__PURE__ */ new Map();
    lastProse = [];
    /** Full extraction + registry rebuild. Returns the new generation. */
    extract(doc = document) {
      const { items, skippedHidden, shadowPierced } = collectInteractives(doc);
      const regItems = items.map((element) => {
        const role = resolveRole(element);
        const { name } = computeAccessibleName(element, doc);
        const states = extractStates(element, role);
        const field = classifyField(element);
        return { element, role, name, states, field };
      });
      const generation = this.registry.rebuild(regItems);
      this.elementToId = /* @__PURE__ */ new Map();
      for (const entry of this.registry.snapshot()) {
        const live = regItems.find((_, index) => `e${index + 1}` === entry.id)?.element;
        if (live !== void 0) this.elementToId.set(live, entry.id);
      }
      this.lastProse = getProseRegions(doc);
      let frames = 0;
      doc.querySelectorAll("iframe,frame,embed,object").forEach(() => {
        frames += 1;
      });
      return {
        url: location.href,
        title: doc.title,
        generation,
        elementCount: regItems.length,
        structure: {
          headings: getHeadings(doc),
          landmarks: getLandmarks(doc),
          forms: getForms(doc),
          openDialogs: getOpenDialogs(doc).length
        },
        prose: this.lastProse,
        skipped: { hidden: skippedHidden, frames, shadow: shadowPierced },
        extractedAt: Date.now()
      };
    }
    /** Registry identity for a live element (announcement/executor use). */
    identify(el) {
      return {
        elementId: this.elementToId.get(el) ?? null,
        generation: this.registry.currentGeneration
      };
    }
    /**
     * Readable container for an element. A heading maps to the article body it
     * introduces, so "read this" on an <h1> yields the article rather than the
     * headline. Falls back to the element itself when no prose region matches.
     */
    proseFor(el) {
      return resolveProseRegionFor(el) ?? el;
    }
    /** Prose regions captured by the most recent extract(). */
    proseRegions() {
      return this.lastProse;
    }
  };

  // src/content/actions.ts
  function setNativeValue(el, value) {
    const prototype = el instanceof HTMLInputElement ? HTMLInputElement.prototype : HTMLTextAreaElement.prototype;
    const descriptor = Object.getOwnPropertyDescriptor(prototype, "value");
    descriptor?.set?.call(el, value);
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }
  function waitForSettled() {
    return new Promise(
      (resolve) => requestAnimationFrame(() => {
        void Promise.resolve().then(resolve);
      })
    );
  }
  var TOGGLE_ROLES = /* @__PURE__ */ new Set(["switch", "checkbox", "combobox", "menuitemcheckbox", "menuitemradio", "radio"]);
  function isToggleTarget(el) {
    const role = el.getAttribute("role");
    if (role !== null && TOGGLE_ROLES.has(role)) return true;
    if (el instanceof HTMLInputElement && (el.type === "checkbox" || el.type === "radio")) return true;
    return false;
  }
  async function performClick(el) {
    if (el instanceof HTMLElement) {
      el.click();
    } else {
      el.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true }));
    }
    if (isToggleTarget(el)) {
      await waitForSettled();
    }
  }
  function performType(el, value, submit) {
    if (!(el instanceof HTMLInputElement) && !(el instanceof HTMLTextAreaElement)) {
      return { ok: false, errorCode: "ACTION_FAILED", detail: "target is not typable" };
    }
    if (el.disabled || el.readOnly) {
      return { ok: false, errorCode: "ACTION_FAILED", detail: "target not editable" };
    }
    el.focus();
    setNativeValue(el, value);
    if (submit === true) {
      el.dispatchEvent(
        new KeyboardEvent("keydown", { key: "Enter", code: "Enter", bubbles: true, cancelable: true })
      );
    }
    return fieldHasValue(el) ? { ok: true } : { ok: false, errorCode: "ACTION_FAILED", detail: "value did not land" };
  }
  function performSelect(el, option) {
    if (!(el instanceof HTMLSelectElement)) {
      return { ok: false, errorCode: "ACTION_FAILED", detail: "target is not a select" };
    }
    const options = [...el.options];
    const match = option.by === "index" && typeof option.ref === "number" ? options[option.ref] ?? null : options.find(
      (o) => option.by === "value" ? o.value === option.ref : o.label === option.ref || o.text === option.ref
    ) ?? null;
    if (match === null) {
      return { ok: false, errorCode: "ELEMENT_NOT_FOUND", detail: "option not found" };
    }
    el.value = match.value;
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    return { ok: true };
  }
  var KEY_MAP = {
    Enter: { key: "Enter", code: "Enter" },
    Tab: { key: "Tab", code: "Tab" },
    Escape: { key: "Escape", code: "Escape" },
    Space: { key: " ", code: "Space" },
    Backspace: { key: "Backspace", code: "Backspace" },
    Delete: { key: "Delete", code: "Delete" },
    ArrowUp: { key: "ArrowUp", code: "ArrowUp" },
    ArrowDown: { key: "ArrowDown", code: "ArrowDown" },
    ArrowLeft: { key: "ArrowLeft", code: "ArrowLeft" },
    ArrowRight: { key: "ArrowRight", code: "ArrowRight" },
    Home: { key: "Home", code: "Home" },
    End: { key: "End", code: "End" },
    PageUp: { key: "PageUp", code: "PageUp" },
    PageDown: { key: "PageDown", code: "PageDown" }
  };
  async function performDomAction(action, registry, generation) {
    if (action.target === void 0) {
      return { ok: false, errorCode: "SCHEMA_VALIDATION_FAILED" };
    }
    const resolved = registry.resolve(action.target, generation);
    if (!resolved.ok) {
      return { ok: false, errorCode: resolved.code === "STALE_TARGET" ? "STALE_TARGET" : "ELEMENT_NOT_FOUND" };
    }
    const el = resolved.entry.element;
    switch (action.action) {
      case "click":
        await performClick(el);
        return { ok: true };
      case "focus":
        if (el instanceof HTMLElement) {
          el.focus();
          return { ok: true };
        }
        return { ok: false, errorCode: "ACTION_FAILED" };
      case "type": {
        const params = action.parameters;
        return performType(el, action.value ?? "", params?.submit === true);
      }
      case "select": {
        const params = action.parameters;
        if (params?.option === void 0 || typeof params.option !== "object" || params.option === null) {
          return { ok: false, errorCode: "SCHEMA_VALIDATION_FAILED" };
        }
        const opt = params.option;
        if (opt.by !== "label" && opt.by !== "value" && opt.by !== "index" || typeof opt.ref !== "string" && typeof opt.ref !== "number") {
          return { ok: false, errorCode: "SCHEMA_VALIDATION_FAILED" };
        }
        return performSelect(el, { by: opt.by, ref: opt.ref });
      }
      case "scroll": {
        const params = action.parameters;
        const direction = params?.direction === "up" || params?.direction === "down" || params?.direction === "left" || params?.direction === "right" ? params.direction : "down";
        const amount = typeof params?.amount_px === "number" ? Math.min(Math.max(params.amount_px, 50), 5e3) : 600;
        if (el instanceof HTMLElement) {
          el.scrollIntoView({ block: "center" });
        }
        const dx = direction === "left" ? -amount : direction === "right" ? amount : 0;
        const dy = direction === "up" ? -amount : direction === "down" ? amount : 0;
        window.scrollBy(dx, dy);
        return { ok: true };
      }
      case "press_key": {
        const params = action.parameters;
        const key = typeof params?.key === "string" ? KEY_MAP[params.key] : void 0;
        if (key === void 0) {
          return { ok: false, errorCode: "SCHEMA_VALIDATION_FAILED" };
        }
        const target = el instanceof HTMLElement ? el : document.body;
        target.dispatchEvent(
          new KeyboardEvent("keydown", {
            key: key.key,
            code: key.code,
            bubbles: true,
            cancelable: true
          })
        );
        target.dispatchEvent(
          new KeyboardEvent("keyup", {
            key: key.key,
            code: key.code,
            bubbles: true,
            cancelable: true
          })
        );
        return { ok: true };
      }
      default:
        return { ok: false, errorCode: "UNSUPPORTED_ACTION" };
    }
  }

  // src/content/page-observer.ts
  var DEBOUNCE_MS = 150;
  var COUNT_DELTA_THRESHOLD = 3;
  function currentUrl() {
    return location.href;
  }
  function countRegions(root) {
    try {
      const deepAll = (selector) => {
        let n = 0;
        const walk = (node) => {
          n += node.querySelectorAll(selector).length;
          node.querySelectorAll("*").forEach((el) => {
            const shadow = el.shadowRoot ?? null;
            if (shadow !== null) walk(shadow);
          });
        };
        walk(root);
        return n;
      };
      const interactives = deepAll(
        "a[href],button,input,select,textarea,[role='button'],[role='link'],[role='checkbox'],[role='menuitem'],[role='tab']"
      );
      const fields = deepAll("input,select,textarea");
      const results = deepAll("[role='list'] > *, ul > li, ol > li");
      const dialogs = deepAll("dialog[open],[role='dialog'],[role='alertdialog']");
      return { interactives, fields, results, dialogs };
    } catch {
      const interactives = root.querySelectorAll(
        "a[href],button,input,select,textarea,[role='button'],[role='link'],[role='checkbox'],[role='menuitem'],[role='tab']"
      ).length;
      const fields = root.querySelectorAll("input,select,textarea").length;
      const results = root.querySelectorAll("[role='list'] > *, ul > li, ol > li").length;
      const dialogs = root.querySelectorAll(
        "dialog[open],[role='dialog'],[role='alertdialog']"
      ).length;
      return { interactives, fields, results, dialogs };
    }
  }
  var STATE_ATTRS = /* @__PURE__ */ new Set([
    "aria-pressed",
    "aria-checked",
    "aria-selected",
    "aria-label",
    "disabled"
  ]);
  var PageObserver = class {
    constructor(root, hooks) {
      this.root = root;
      this.hooks = hooks;
      this.baseline = countRegions(root);
    }
    root;
    hooks;
    observer = null;
    timer = null;
    lastUrl = currentUrl();
    baseline;
    disposers = [];
    stateDirty = false;
    start() {
      if (this.observer !== null) return;
      this.wrapHistory("pushState");
      this.wrapHistory("replaceState");
      const onPopState = () => this.checkRoute("popstate");
      window.addEventListener("popstate", onPopState);
      this.disposers.push(() => window.removeEventListener("popstate", onPopState));
      const onPageShow = (e) => {
        if (e.persisted) this.hooks.onTrigger("bfcache", "restored from bfcache; revalidate");
      };
      window.addEventListener("pageshow", onPageShow);
      this.disposers.push(() => window.removeEventListener("pageshow", onPageShow));
      this.observer = new MutationObserver((records) => {
        for (const record of records) {
          if (record.type === "attributes" && typeof record.attributeName === "string" && STATE_ATTRS.has(record.attributeName)) {
            this.stateDirty = true;
            break;
          }
        }
        this.schedule();
      });
      this.observer.observe(this.root, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: [
          "aria-busy",
          "open",
          "aria-expanded",
          "aria-hidden",
          "hidden",
          "aria-pressed",
          "aria-checked",
          "aria-selected",
          "aria-label",
          "disabled"
        ]
      });
    }
    stop() {
      this.observer?.disconnect();
      this.observer = null;
      if (this.timer !== null) {
        clearTimeout(this.timer);
        this.timer = null;
      }
      this.disposers.forEach((d) => d());
      this.disposers = [];
    }
    wrapHistory(method) {
      const original = history[method].bind(history);
      const self = this;
      history[method] = function(...args) {
        original(...args);
        self.checkRoute(method);
      };
      this.disposers.push(() => {
        history[method] = original;
      });
    }
    checkRoute(source) {
      const now = currentUrl();
      if (now !== this.lastUrl) {
        this.lastUrl = now;
        this.rebaseline();
        this.hooks.onTrigger("route", `${source}: ${now}`);
      }
    }
    schedule() {
      if (this.timer !== null) return;
      this.timer = setTimeout(() => {
        this.timer = null;
        this.classify();
      }, DEBOUNCE_MS);
    }
    /** Testable classification core: compares fresh counts to the baseline. */
    classifyNow() {
      return this.classify();
    }
    classify() {
      if (!document.contains(this.root) && this.root === document.body) {
        this.rebaseline();
        this.hooks.onTrigger("root", "document body replaced");
        return "root";
      }
      const fresh = countRegions(this.root);
      if (fresh.dialogs !== this.baseline.dialogs) {
        this.rebaseline(fresh);
        this.hooks.onTrigger("modal", `dialog count ${this.baseline.dialogs}\u2192${fresh.dialogs}`);
        return "modal";
      }
      if (fresh.fields !== this.baseline.fields) {
        this.rebaseline(fresh);
        this.hooks.onTrigger("form-structure", `field count ${this.baseline.fields}\u2192${fresh.fields}`);
        return "form-structure";
      }
      if (Math.abs(fresh.results - this.baseline.results) > 0) {
        const before = this.baseline.results;
        this.rebaseline(fresh);
        this.hooks.onTrigger("results", `results count ${before}\u2192${fresh.results}`);
        return "results";
      }
      if (Math.abs(fresh.interactives - this.baseline.interactives) >= COUNT_DELTA_THRESHOLD) {
        const before = this.baseline.interactives;
        this.rebaseline(fresh);
        this.hooks.onTrigger("counts", `interactive count ${before}\u2192${fresh.interactives}`);
        return "counts";
      }
      if (this.stateDirty) {
        this.stateDirty = false;
        this.rebaseline(fresh);
        this.hooks.onTrigger("state", "control state changed");
        return "state";
      }
      const busy = this.root.querySelector?.(
        "[aria-busy='true']"
      );
      void busy;
      return "minor";
    }
    rebaseline(next) {
      this.baseline = next ?? countRegions(this.root);
      this.lastUrl = currentUrl();
      this.stateDirty = false;
    }
  };

  // src/verification/verification-engine.ts
  function decided(outcome) {
    return outcome;
  }
  function evaluateExpectation(expect, facts) {
    const navigatedAway = facts.urlNow !== facts.urlBefore;
    switch (expect.type) {
      case "element_present":
        if (facts.targetPresent === true) return decided("VERIFIED_SUCCESS");
        if (navigatedAway) return decided("STALE_STATE");
        return "PENDING";
      case "element_absent":
        if (facts.targetPresent === false) return decided("VERIFIED_SUCCESS");
        if (navigatedAway) return decided("STALE_STATE");
        return "PENDING";
      case "focused_element":
        if (facts.activeMatches === true) return decided("VERIFIED_SUCCESS");
        if (navigatedAway) return decided("STALE_STATE");
        return "PENDING";
      case "url_changed":
      case "navigation_completed":
        if (facts.urlNow !== facts.urlBefore) return decided("VERIFIED_SUCCESS");
        return "PENDING";
      case "dialog_present":
        if (facts.dialogOpen) return decided("VERIFIED_SUCCESS");
        if (navigatedAway) return decided("STALE_STATE");
        return "PENDING";
      case "text_present":
        if (facts.textFound === true) return decided("VERIFIED_SUCCESS");
        if (facts.textFound === null) return decided("UNKNOWN");
        if (navigatedAway) return decided("STALE_STATE");
        return "PENDING";
      case "field_value_present":
        if (facts.fieldFilled === true) return decided("VERIFIED_SUCCESS");
        if (facts.fieldFilled === null) return decided("UNKNOWN");
        if (navigatedAway) return decided("STALE_STATE");
        return "PENDING";
      case "element_state":
        if (facts.stateMatches === true) return decided("VERIFIED_SUCCESS");
        if (facts.stateMatches === null) return decided("UNKNOWN");
        if (navigatedAway) return decided("STALE_STATE");
        return "PENDING";
      case "submit_completed":
        return evaluateSubmit(facts);
      default:
        return decided("UNKNOWN");
    }
  }
  function evaluateSubmit(facts) {
    const s = facts.submit;
    if (s === void 0) return "PENDING";
    if (s.navigated === true) return decided("VERIFIED_SUCCESS");
    if (s.successDialogOpen === true) return decided("VERIFIED_SUCCESS");
    if (s.successTextFound === true) return decided("VERIFIED_SUCCESS");
    if (s.submittedTargetGone === true) return decided("VERIFIED_SUCCESS");
    if (s.targetDisabled === true) return decided("VERIFIED_SUCCESS");
    return "PENDING";
  }

  // src/verification/submit-verification.ts
  var SUCCESS_TEXT_PATTERNS = [
    /\bsubmitted\b/i,
    /\bsent\b/i,
    /\bapplication (?:was )?received\b/i,
    /\breceived\b/i,
    /\bsuccessfully\b/i,
    /\bsuccess(?:ful)?\b/i,
    /\bthank you\b/i,
    /\bthanks for\b/i,
    /\bconfirmation (?:email )?(?:sent|received)\b/i,
    /\bconfirmed\b/i,
    /\bwe(?:'ve| have) (?:received|got|registered)\b/i,
    /\bhas been (?:submitted|sent|received|applied|registered|created|saved)\b/i,
    /\bwas (?:submitted|sent|received|applied|registered|created|saved)\b/i,
    /\bcomplete\b/i,
    /\bcompleted\b/i,
    /\bqueued\b/i,
    /\baccepted\b/i,
    /\bapproved\b/i,
    /\bverified\b/i,
    /\bcongratulations\b/i
  ];
  var STATUS_SELECTOR = '[role="alert"],[role="status"],[role="alertdialog"],dialog[open],[aria-live="assertive"],[aria-live="polite"],[class*="toast" i],[class*="snackbar" i],[class*="notification" i],[class*="success" i],[data-testid*="success" i],[data-testid*="toast" i],[data-testid*="alert" i]';
  var MAX_SCAN_CHARS = 4e3;
  function looksLikeCompletionText(text) {
    const clean = text.replace(/\s+/gu, " ").trim().slice(0, MAX_SCAN_CHARS);
    if (clean === "") return false;
    return SUCCESS_TEXT_PATTERNS.some((re) => re.test(clean));
  }
  function collectCompletionSignals(doc, targetId, options) {
    const navigated = doc.location?.href !== void 0 ? doc.location.href !== options.urlBefore : null;
    let successDialogOpen = null;
    try {
      const dialogs = doc.querySelectorAll(
        'dialog[open],[role="dialog"],[role="alertdialog"]'
      );
      for (const el of Array.from(dialogs)) {
        const text = (el.textContent ?? "").replace(/\s+/gu, " ").trim();
        if (looksLikeCompletionText(text)) {
          successDialogOpen = true;
          break;
        }
      }
      if (successDialogOpen !== true) successDialogOpen = false;
    } catch {
      successDialogOpen = null;
    }
    let successTextFound = null;
    try {
      const regions = doc.querySelectorAll(STATUS_SELECTOR);
      for (const el of Array.from(regions)) {
        if (looksLikeCompletionText((el.textContent ?? "").replace(/\s+/gu, " "))) {
          successTextFound = true;
          break;
        }
      }
      if (successTextFound !== true) successTextFound = false;
    } catch {
      successTextFound = null;
    }
    let submittedTargetGone = null;
    if (options.targetMissingFromRegistry === true || options.identityMissing === true) {
      submittedTargetGone = true;
    } else if (targetId !== void 0 && options.resolveTarget !== void 0) {
      try {
        submittedTargetGone = options.resolveTarget(targetId) === null;
      } catch {
        submittedTargetGone = null;
      }
    }
    let targetDisabled = null;
    if (targetId !== void 0 && options.resolveTarget !== void 0) {
      try {
        const el = options.resolveTarget(targetId);
        if (el !== null) {
          targetDisabled = el instanceof HTMLButtonElement && el.disabled || el.getAttribute("aria-disabled") === "true" || el.hasAttribute("disabled");
        } else {
          targetDisabled = null;
        }
      } catch {
        targetDisabled = null;
      }
    }
    return { successDialogOpen, successTextFound, submittedTargetGone, targetDisabled, navigated };
  }

  // ../node_modules/thinking-orbs/dist/index-B8WsUNf5.js
  function lerp(a, b, f) {
    return a + (b - a) * f;
  }
  function frac(x) {
    return x - Math.floor(x);
  }
  function vnoise(x, y) {
    const xi = Math.floor(x);
    const yi = Math.floor(y);
    let fx = x - xi;
    let fy = y - yi;
    fx = fx * fx * (3 - 2 * fx);
    fy = fy * fy * (3 - 2 * fy);
    const a = hashD(xi, yi);
    const b = hashD(xi + 1, yi);
    const c = hashD(xi, yi + 1);
    const d = hashD(xi + 1, yi + 1);
    return a + (b - a) * fx + (c - a) * fy + (a - b - c + d) * fx * fy;
  }
  function hashD(a, b) {
    const h = Math.sin(a * 12.9898 + b * 78.233) * 43758.5453;
    return h - Math.floor(h);
  }
  function fibDir(i, n) {
    const golden = Math.PI * (3 - Math.sqrt(5));
    const y = 1 - 2 * (i + 0.5) / n;
    const rad = Math.sqrt(1 - y * y);
    const a = i * golden;
    return [rad * Math.cos(a), y, rad * Math.sin(a)];
  }
  function angleDelta(a, b) {
    return Math.atan2(Math.sin(a - b), Math.cos(a - b));
  }
  function makeProj(yaw, tilt, cx, cy, scale) {
    const st = Math.sin(tilt);
    const ct = Math.cos(tilt);
    const sy = Math.sin(yaw);
    const cyw = Math.cos(yaw);
    return (x, y, z) => {
      const x1 = x * cyw + z * sy;
      const z1 = -x * sy + z * cyw;
      const y1 = y * ct - z1 * st;
      const z2 = y * st + z1 * ct;
      return [cx + x1 * scale, cy - y1 * scale, z2];
    };
  }
  function inkColor(w, alpha, dark, tint) {
    if (!tint) {
      const g = Math.round((dark ? 1 - w : w) * 255);
      return `rgba(${g},${g},${g},${alpha})`;
    }
    const ramp = (c) => Math.round(dark ? c * (1 - w) : c + (255 - c) * w);
    return `rgba(${ramp(tint.r)},${ramp(tint.g)},${ramp(tint.b)},${alpha})`;
  }
  function paint(ctx, dots, dark, rMin = 0.3, tint) {
    for (const d of dots) {
      const alpha = d.a ?? 1;
      const w = Math.min(1, Math.max(0, d.white));
      ctx.fillStyle = inkColor(w, alpha, dark, tint);
      ctx.beginPath();
      ctx.arc(d.x, d.y, d.r, 0, Math.PI * 2);
      ctx.fill();
    }
  }
  function paintLines(ctx, lines, dark, tint) {
    for (const l of lines) {
      const alpha = l.a ?? 1;
      const w = Math.min(1, Math.max(0, l.white));
      ctx.strokeStyle = inkColor(w, alpha, dark, tint);
      ctx.lineWidth = l.w;
      ctx.beginPath();
      ctx.moveTo(l.x1, l.y1);
      ctx.lineTo(l.x2, l.y2);
      ctx.stroke();
    }
  }
  function finalizeFrame(dots, lines, rMin = 0.3) {
    const visible = [];
    for (const d of dots) {
      if ((d.a ?? 1) < 0.02) continue;
      d.r = Math.max(rMin, d.r);
      visible.push(d);
    }
    visible.sort((a, b) => a.z - b.z);
    return { dots: visible, lines: lines.filter((l) => (l.a ?? 1) >= 0.02) };
  }
  function paintFrame(ctx, frame, dark, tint) {
    if (frame.lines.length) paintLines(ctx, frame.lines, dark, tint);
    paint(ctx, frame.dots, dark, 0.3, tint);
  }
  function radiusScale(size, pow) {
    return (size / 300) ** pow;
  }
  var COUNT_PAIRS = [
    ["latRings", "lonDensity"],
    ["rings", "lonDensity"],
    ["lanes", "segs"]
  ];
  var COUNT_KEYS = ["orbitN", "ghostN", "nodeN", "strandN", "signals"];
  var ICON_DENSITY_KEYS = ["iconD"];
  var RADIUS_KEYS = [
    "rBase",
    "rDepth",
    "rActive",
    "rDot",
    "ghostR",
    "partR",
    "partRDepth",
    "nodeR",
    "nodeRDepth"
  ];
  function scaleCounts(opts, scale) {
    const out = { ...opts };
    const done = /* @__PURE__ */ new Set();
    const rt = Math.sqrt(scale);
    for (const [a, b] of COUNT_PAIRS) {
      const va = out[a];
      const vb = out[b];
      if (va != null && vb != null && !done.has(a) && !done.has(b)) {
        out[a] = Math.max(2, Math.round(va * rt));
        out[b] = Math.max(2, Math.round(vb * rt));
        done.add(a);
        done.add(b);
      }
    }
    for (const k of COUNT_KEYS) {
      const v = out[k];
      if (v != null && v !== 0 && !done.has(k)) out[k] = Math.max(1, Math.round(v * scale));
    }
    for (const k of ICON_DENSITY_KEYS) {
      const v = out[k];
      if (v != null) out[k] = Math.max(0.02, v * scale);
    }
    return out;
  }
  function scaleRadii(opts, scale) {
    const out = { ...opts };
    for (const k of RADIUS_KEYS) {
      const v = out[k];
      if (v != null) out[k] = v * scale;
    }
    out.rSizeMul = (out.rSizeMul ?? 1) * scale;
    return out;
  }
  var BASE_PROFILES = {
    globe: {
      latRings: 17,
      lonDensity: 44,
      rBase: 0.6,
      rDepth: 1.7,
      rBoost: 1,
      inkFar: 0.62,
      inkSpan: 0.54,
      rsPow: 0.6,
      rMin: 0.3
    },
    orbits: {
      orbitN: 12,
      ghostN: 40,
      ghostR: 0.9,
      ghostA: 0.5,
      particles: 3,
      partR: 1.2,
      partRDepth: 1.6,
      rsPow: 0.6,
      rMin: 0.3
    },
    rubik: {
      latRings: 15,
      lonDensity: 40,
      moveCount: 14,
      rBase: 0.6,
      rDepth: 1.7,
      rActive: 0.3,
      inkFar: 0.62,
      inkSpan: 0.54,
      rsPow: 0.6,
      rMin: 0.3
    },
    wave: {
      rings: 15,
      lonDensity: 40,
      rBase: 0.6,
      rDepth: 1.7,
      rsPow: 0.6,
      rMin: 0.3
    },
    web: {
      nodeN: 30,
      thr: 0.72,
      signals: 5,
      nodeR: 1.4,
      nodeRDepth: 1.8,
      lineW: 0.8,
      rsPow: 0.6,
      rMin: 0.3
    },
    braid: {
      strandN: 52,
      turns: 3,
      ghostN: 150,
      rBase: 1.2,
      rDepth: 1.8,
      rsPow: 0.6,
      rMin: 0.3
    },
    ribbon: {
      lanes: 5,
      segs: 88,
      ghostN: 150,
      rBase: 1.1,
      rDepth: 1.7,
      rsPow: 0.6,
      rMin: 0.3
    },
    // ring shares ribbon's painter; faceOn cancels the camera tilt and moves
    // the undulation onto the radius, and there is no ghost sphere behind it
    ring: {
      lanes: 5,
      segs: 88,
      ghostN: 0,
      faceOn: 1,
      rBase: 1.1,
      rDepth: 1.7,
      rsPow: 0.6,
      rMin: 0.3
    },
    morph: {
      rDot: 0.021,
      iconD: 1,
      rMin: 0.25
    }
  };
  var frameBraid = (size, t, o) => {
    const cx = size / 2;
    const cy = size / 2;
    const R = size / 2 * 0.76;
    const pt = makeProj(t * 0.4, 0.3, cx, cy, 1);
    const rs = radiusScale(size, o.rsPow ?? 0.6);
    const dots = [];
    const ghostN = o.ghostN ?? 150;
    for (let i = 0; i < ghostN; i++) {
      const d = fibDir(i, ghostN);
      const [px, py, z] = pt(d[0] * R, d[1] * R, d[2] * R);
      const depth = (z / R + 1) / 2;
      dots.push({ x: px, y: py, z, r: 0.8 * rs, white: 0.78, a: 0.1 + 0.22 * depth });
    }
    const strandN = o.strandN ?? 52;
    const turns = o.turns ?? 3;
    for (let s = 0; s < 3; s++) {
      const phase = s / 3 * 2 * Math.PI;
      for (let i = 0; i < strandN; i++) {
        const u = (frac(i / strandN + t * 0.045) * 2 - 1) * 0.96;
        const surf = Math.sqrt(Math.max(0, 1 - u * u));
        const endFade = Math.min(1, (1 - Math.abs(u)) / 0.1);
        const a = u * Math.PI * turns + phase;
        const weave = 1 + 0.075 * Math.sin(u * Math.PI * turns * 2 + phase * 2 + t * 0.8);
        const rr = surf * R * weave;
        const [px, py, zr] = pt(Math.cos(a) * rr, u * R * weave, Math.sin(a) * rr);
        const depth = (zr / R + 1) / 2;
        dots.push({
          x: px,
          y: py,
          z: zr,
          r: ((o.rBase ?? 1.2) + (o.rDepth ?? 1.8) * depth) * rs,
          white: 0.55 - 0.45 * depth,
          a: endFade * (0.45 + 0.55 * depth)
        });
      }
    }
    return finalizeFrame(dots, [], o.rMin);
  };
  function solveCycle(time, count, slotDur, rest) {
    const cyc = 2 * count * slotDur + rest;
    const tc = time % cyc;
    const amount = new Array(count).fill(0);
    let active = -1;
    if (tc < 2 * count * slotDur) {
      const slot = Math.floor(tc / slotDur);
      const p = (tc - slot * slotDur) / slotDur;
      const cl = Math.min(1, p / 0.7);
      const ep = 1 - (1 - cl) ** 3;
      if (slot < count) {
        for (let i = 0; i < slot; i++) amount[i] = 1;
        amount[slot] = ep;
        active = slot;
      } else {
        const u = 2 * count - 1 - slot;
        for (let i = 0; i < u; i++) amount[i] = 1;
        amount[u] = 1 - ep;
        active = u;
      }
    }
    return { amount, active };
  }
  function applyMoves(pt3, moves, sc) {
    let [x, y, z] = pt3;
    let inActive = false;
    for (let i = 0; i < moves.length; i++) {
      if (sc.amount[i] <= 0) continue;
      const mv = moves[i];
      const coord = mv.axis === 0 ? x : mv.axis === 1 ? y : z;
      if (coord < mv.lo || coord >= mv.hi) continue;
      if (i === sc.active) inActive = true;
      const a = mv.ang * sc.amount[i];
      const ca = Math.cos(a);
      const sa = Math.sin(a);
      if (mv.axis === 0) {
        const y2 = y * ca - z * sa;
        z = y * sa + z * ca;
        y = y2;
      } else if (mv.axis === 1) {
        const x2 = x * ca + z * sa;
        z = -x * sa + z * ca;
        x = x2;
      } else {
        const x2 = x * ca - y * sa;
        y = x * sa + y * ca;
        x = x2;
      }
    }
    return [x, y, z, inActive];
  }
  function makeMoves(count) {
    const moves = [];
    for (let i = 0; i < count; i++) {
      const axis = Math.min(2, Math.floor(hashD(i, 2.3) * 3));
      const lo = -1 + 0.5 * Math.min(3, Math.floor(hashD(i, 5.9) * 4));
      const dir = hashD(i, 7.7) < 0.5 ? 1 : -1;
      moves.push({ axis, lo, hi: lo + 0.5, ang: dir * Math.PI / 2 });
    }
    return moves;
  }
  var frameGlobe = (size, t, o) => {
    const spin = 0.5;
    const cx = size / 2;
    const cy = size / 2;
    const radius = size / 2 * 0.82;
    const tilt = 0.4 + 0.06 * Math.sin(t * 0.35);
    const pt = makeProj(t * spin, tilt, cx, cy, radius);
    const scan = t * (spin + (1.7 - spin) * (o.scanMul ?? 1));
    const rs = radiusScale(size, o.rsPow ?? 0.6);
    const dimBase = o.dimBase ?? 1;
    const dots = [];
    const latRings = o.latRings ?? 17;
    const lonDensity = o.lonDensity ?? 44;
    for (let li = 0; li <= latRings; li++) {
      const lat = -Math.PI / 2 + li / latRings * Math.PI;
      const cosLat = Math.cos(lat);
      const sinLat = Math.sin(lat);
      const lonCount = Math.max(1, Math.round(Math.abs(cosLat) * lonDensity));
      for (let lj = 0; lj < lonCount; lj++) {
        const lon = lj / lonCount * 2 * Math.PI;
        const [px, py, z] = pt(cosLat * Math.cos(lon), sinLat, cosLat * Math.sin(lon));
        const depth = (z + 1) / 2;
        const d = angleDelta(lon + t * spin, scan);
        const boost = Math.exp(-(d * d) / 0.18) * Math.max(0, z);
        dots.push({
          x: px,
          y: py,
          z,
          r: ((o.rBase ?? 0.6) + (o.rDepth ?? 1.7) * depth + (o.rBoost ?? 1) * boost) * rs,
          white: (o.inkFar ?? 0.62) - (o.inkSpan ?? 0.54) * depth,
          // dimBase < 1 fades un-scanned dots so the meridian reads clearly
          a: dimBase + (1 - dimBase) * Math.min(1, boost)
        });
      }
    }
    return finalizeFrame(dots, [], o.rMin);
  };
  var frameRubik = (size, t, o) => {
    const cx = size / 2;
    const cy = size / 2;
    const R = size / 2 * 0.82;
    const pt = makeProj(t * 0.55, 0.35 + 0.1 * Math.sin(t * 0.9), cx, cy, R);
    const rs = radiusScale(size, o.rsPow ?? 0.6);
    const moveCount = o.moveCount ?? 14;
    const moves = makeMoves(moveCount);
    const sc = solveCycle(t, moveCount, 0.42, 1.2);
    const dots = [];
    const latRings = o.latRings ?? 15;
    const lonDensity = o.lonDensity ?? 40;
    for (let li = 0; li <= latRings; li++) {
      const lat = -Math.PI / 2 + li / latRings * Math.PI;
      const cosLat = Math.cos(lat);
      const sinLat = Math.sin(lat);
      const lonCount = Math.max(1, Math.round(Math.abs(cosLat) * lonDensity));
      for (let lj = 0; lj < lonCount; lj++) {
        const lon = lj / lonCount * 2 * Math.PI;
        const [x, y, z, inActive] = applyMoves([cosLat * Math.cos(lon), sinLat, cosLat * Math.sin(lon)], moves, sc);
        const [px, py, zr] = pt(x, y, z);
        const depth = (zr + 1) / 2;
        dots.push({
          x: px,
          y: py,
          z: zr,
          r: ((o.rBase ?? 0.6) + (o.rDepth ?? 1.7) * depth + (inActive ? o.rActive ?? 0.3 : 0)) * rs,
          white: (o.inkFar ?? 0.62) - (o.inkSpan ?? 0.54) * depth - (inActive ? 0.14 : 0)
        });
      }
    }
    return finalizeFrame(dots, [], o.rMin);
  };
  var frameWave = (size, t, o) => {
    const cx = size / 2;
    const cy = size / 2;
    const R = size / 2 * 0.874;
    const pt = makeProj(t * 0.18, 0.38, cx, cy, 1);
    const rs = radiusScale(size, o.rsPow ?? 0.6);
    const dots = [];
    const rings = o.rings ?? 15;
    const lonDensity = o.lonDensity ?? 40;
    for (let ri = 0; ri <= rings; ri++) {
      const lat = -Math.PI / 2 + ri / rings * Math.PI;
      const cosLat = Math.cos(lat);
      const sinLat = Math.sin(lat);
      const w = 0.62 * Math.sin(t * 2.1 - ri * 0.52) + 0.38 * Math.sin(t * 1.27 + ri * 0.83);
      const rr = R * (0.88 + 0.105 * w);
      const lonCount = Math.max(1, Math.round(Math.abs(cosLat) * lonDensity));
      for (let lj = 0; lj < lonCount; lj++) {
        const lon = lj / lonCount * 2 * Math.PI;
        const [px, py, z] = pt(cosLat * Math.cos(lon) * rr, sinLat * rr, cosLat * Math.sin(lon) * rr);
        const depth = (z / R + 1) / 2;
        const crest = Math.max(0, w);
        dots.push({
          x: px,
          y: py,
          z,
          r: ((o.rBase ?? 0.6) + (o.rDepth ?? 1.7) * depth) * (1 + 0.4 * crest) * rs,
          white: 0.66 - 0.56 * depth - 0.1 * crest
        });
      }
    }
    return finalizeFrame(dots, [], o.rMin);
  };
  function smoothE(x) {
    return x * x * (3 - 2 * x);
  }
  function polyPath(verts) {
    const V = verts.length;
    const L = [];
    let total = 0;
    for (let i = 0; i < V; i++) {
      const a = verts[i];
      const b = verts[(i + 1) % V];
      const l = Math.hypot(b[0] - a[0], b[1] - a[1]);
      L.push(l);
      total += l;
    }
    return (f) => {
      let target = f * total;
      let i = 0;
      while (target > L[i] && i < V - 1) {
        target -= L[i];
        i++;
      }
      const a = verts[i];
      const b = verts[(i + 1) % V];
      const ff = L[i] ? Math.min(1, target / L[i]) : 0;
      return [a[0] + (b[0] - a[0]) * ff, a[1] + (b[1] - a[1]) * ff];
    };
  }
  var CIRCLE = (f) => {
    const a = -Math.PI / 2 + f * 2 * Math.PI;
    return [Math.cos(a) * 0.24, Math.sin(a) * 0.24];
  };
  var TRIANGLE = polyPath([
    [0, -0.26],
    [0.24, 0.16],
    [-0.24, 0.16]
  ]);
  var SQUARE = polyPath([
    [0, -0.2],
    [0.2, -0.2],
    [0.2, 0.2],
    [-0.2, 0.2],
    [-0.2, -0.2]
  ]);
  var CYCLE = [CIRCLE, TRIANGLE, SQUARE];
  function morphN(d) {
    return Math.max(6, Math.round(34 * d));
  }
  var HOLD = 1.4;
  var MORPH = 0.9;
  var SEG = HOLD + MORPH;
  var frameMorph = (size, t, o) => {
    const K = CYCLE.length;
    const tc = t % (SEG * K);
    const held = o.shape != null && o.shape >= 0 && o.shape < K ? Math.floor(o.shape) : -1;
    const k = held >= 0 ? held : Math.floor(tc / SEG);
    const local = held >= 0 ? t % SEG : tc - k * SEG;
    const m = held >= 0 ? 0 : local > HOLD ? smoothE((local - HOLD) / MORPH) : 0;
    const sprd = o.spread ?? 1;
    const pA = CYCLE[k];
    const pB = held >= 0 ? pA : CYCLE[(k + 1) % K];
    const M = 160;
    const pts = [];
    for (let i = 0; i < M; i++) {
      const f = i / M;
      const a = pA(f);
      const b = pB(f);
      pts.push([(a[0] + (b[0] - a[0]) * m) * sprd, (a[1] + (b[1] - a[1]) * m) * sprd]);
    }
    const L = [];
    let total = 0;
    for (let i = 0; i < M; i++) {
      const a = pts[i];
      const b = pts[(i + 1) % M];
      const l = Math.hypot(b[0] - a[0], b[1] - a[1]);
      L.push(l);
      total += l;
    }
    const n = morphN(o.iconD ?? 1);
    const re = (o.rDot ?? 0.021) * 1.35 * sprd;
    const pulse = 1 + 0.02 * Math.sin(local * 3.1);
    const dots = [];
    const c2 = size / 2;
    let seg = 0;
    let acc = 0;
    for (let k2 = 0; k2 < n; k2++) {
      const target = k2 / n * total;
      while (acc + L[seg] < target && seg < M - 1) {
        acc += L[seg];
        seg++;
      }
      const a = pts[seg];
      const b = pts[(seg + 1) % M];
      const f = L[seg] ? Math.min(1, (target - acc) / L[seg]) : 0;
      const x = (a[0] + (b[0] - a[0]) * f) * pulse;
      const y = (a[1] + (b[1] - a[1]) * f) * pulse;
      dots.push({
        x: c2 + x * size,
        y: c2 + y * size,
        z: 0,
        r: Math.max(0.35, re * size),
        white: 0.1
      });
    }
    return finalizeFrame(dots, [], o.rMin);
  };
  var frameOrbits = (size, t, o) => {
    const cx = size / 2;
    const cy = size / 2;
    const R = size / 2 * 0.82;
    const pt = makeProj(t * 0.12, 0.3, cx, cy, 1);
    const rs = radiusScale(size, o.rsPow ?? 0.6);
    const dots = [];
    const orbitN = o.orbitN ?? 12;
    const ghostN = o.ghostN ?? 40;
    const particles = o.particles ?? 3;
    for (let orb = 0; orb < orbitN; orb++) {
      const h1 = hashD(orb, 1.7);
      const h2 = hashD(orb, 5.2);
      const h3 = hashD(orb, 8.9);
      const ro = R * (0.45 + 0.52 * h1);
      const th = h1 * 2 * Math.PI;
      const phi = Math.acos(2 * h2 - 1);
      const nx = Math.sin(phi) * Math.cos(th);
      const ny = Math.cos(phi);
      const nz = Math.sin(phi) * Math.sin(th);
      let ux = -ny;
      let uy = nx;
      const uz = 0;
      const ul = Math.max(1e-6, Math.sqrt(ux * ux + uy * uy));
      ux /= ul;
      uy /= ul;
      const vx = ny * uz - nz * uy;
      const vy = nz * ux - nx * uz;
      const vz = nx * uy - ny * ux;
      const speed = (0.25 + 0.55 * h3) * (h3 > 0.5 ? 1 : -1);
      for (let k = 0; k < ghostN; k++) {
        const a = k / ghostN * 2 * Math.PI;
        const [px, py, z] = pt(
          (ux * Math.cos(a) + vx * Math.sin(a)) * ro,
          (uy * Math.cos(a) + vy * Math.sin(a)) * ro,
          (uz * Math.cos(a) + vz * Math.sin(a)) * ro
        );
        const depth = (z / ro + 1) / 2;
        dots.push({
          x: px,
          y: py,
          z,
          r: (o.ghostR ?? 0.9) * rs,
          white: 0.72,
          a: (o.ghostA ?? 0.5) * (0.4 + 0.6 * depth)
        });
      }
      for (let m = 0; m < particles; m++) {
        const a = t * speed + m / particles * 2 * Math.PI + h2 * 6;
        const [px, py, z] = pt(
          (ux * Math.cos(a) + vx * Math.sin(a)) * ro,
          (uy * Math.cos(a) + vy * Math.sin(a)) * ro,
          (uz * Math.cos(a) + vz * Math.sin(a)) * ro
        );
        const depth = (z / ro + 1) / 2;
        dots.push({
          x: px,
          y: py,
          z,
          r: ((o.partR ?? 1.2) + (o.partRDepth ?? 1.6) * depth) * rs,
          white: 0.3 - 0.22 * depth
        });
      }
    }
    return finalizeFrame(dots, [], o.rMin);
  };
  var frameRibbon = (size, t, o) => {
    const cx = size / 2;
    const cy = size / 2;
    const R = size / 2 * 0.78;
    const spin = o.spin ?? 1;
    const camTilt = 0.3;
    const pt = makeProj(t * 0.1 * spin, camTilt, cx, cy, 1);
    const rs = radiusScale(size, o.rsPow ?? 0.6);
    const dots = [];
    const ghostN = o.ghostN ?? 150;
    for (let i = 0; i < ghostN; i++) {
      const d = fibDir(i, ghostN);
      const [px, py, z] = pt(d[0] * R, d[1] * R, d[2] * R);
      const depth = (z / R + 1) / 2;
      dots.push({ x: px, y: py, z, r: 0.8 * rs, white: 0.78, a: 0.1 + 0.22 * depth });
    }
    const ya = t * 0.24 * spin;
    const ta = o.faceOn ? -camTilt : 0.55 + 0.3 * Math.sin(t * 0.18) * spin;
    const ux = Math.cos(ya);
    const uy = 0;
    const uz = Math.sin(ya);
    const vx = -uz * Math.sin(ta);
    const vy = Math.cos(ta);
    const vz = ux * Math.sin(ta);
    const nx = uy * vz - uz * vy;
    const ny = uz * vx - ux * vz;
    const nz = ux * vy - uy * vx;
    const wobAmp = 0.23 * (o.wobMul ?? 1);
    const baseR = o.faceOn ? R / (1 + 0.85 * wobAmp) : R;
    const baseLanes = o.lanes ?? 5;
    const segs = o.segs ?? 88;
    const lanes = Math.max(1, Math.round(baseLanes * (o.bandMul ?? 1)));
    for (let w = 0; w < lanes; w++) {
      const laneOff = (w - (lanes - 1) / 2) * 0.075;
      const edge = Math.abs(w - (lanes - 1) / 2) / Math.max(1, (lanes - 1) / 2);
      for (let k = 0; k < segs; k++) {
        const a = k / segs * 2 * Math.PI;
        const wob = (0.16 * Math.sin(a * 3 - t * 1.7 + w * 0.22) + 0.07 * Math.sin(a * 5 + t * 1.1)) * (o.wobMul ?? 1);
        const radial = o.faceOn ? 1 + wob : 1;
        const off = o.faceOn ? laneOff : laneOff + wob;
        const x = ux * Math.cos(a) + vx * Math.sin(a) + nx * off;
        const y = uy * Math.cos(a) + vy * Math.sin(a) + ny * off;
        const z = uz * Math.cos(a) + vz * Math.sin(a) + nz * off;
        const l = Math.sqrt(x * x + y * y + z * z);
        const rr = baseR * radial;
        const [px, py, zr] = pt(x / l * rr, y / l * rr, z / l * rr);
        const depth = (zr / R + 1) / 2;
        dots.push({
          x: px,
          y: py,
          z: zr,
          r: ((o.rBase ?? 1.1) + (o.rDepth ?? 1.7) * depth) * (1 - 0.25 * edge) * rs,
          white: 0.52 - 0.44 * depth + 0.18 * edge,
          a: 0.4 + 0.6 * depth
        });
      }
    }
    return finalizeFrame(dots, [], o.rMin);
  };
  var frameWeb = (size, t, o) => {
    const cx = size / 2;
    const cy = size / 2;
    const R = size / 2 * 0.8 * (o.spread ?? 1);
    const pt = makeProj(t * 0.12, 0.32, cx, cy, R);
    const rs = radiusScale(size, o.rsPow ?? 0.6);
    const nodeN = o.nodeN ?? 30;
    const thr = o.thr ?? 0.72;
    const nodeR = o.nodeR ?? 1.4;
    const nodeRDepth = o.nodeRDepth ?? 1.8;
    const nodes = [];
    for (let i = 0; i < nodeN; i++) {
      const d = fibDir(i, nodeN);
      const x = d[0] + 0.3 * (vnoise(i * 0.31 + 9, t * 0.24) - 0.5) * 2;
      const y = d[1] + 0.3 * (vnoise(i * 0.53 + 27, t * 0.21) - 0.5) * 2;
      const z = d[2] + 0.3 * (vnoise(i * 0.77 + 55, t * 0.27) - 0.5) * 2;
      const l = Math.sqrt(x * x + y * y + z * z);
      nodes.push([x / l, y / l, z / l]);
    }
    const lines = [];
    const dots = [];
    for (let i = 0; i < nodeN; i++) {
      for (let j = i + 1; j < nodeN; j++) {
        const dx = nodes[i][0] - nodes[j][0];
        const dy = nodes[i][1] - nodes[j][1];
        const dz = nodes[i][2] - nodes[j][2];
        const dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (dist >= thr) continue;
        const [x1, y1, z1] = pt(nodes[i][0], nodes[i][1], nodes[i][2]);
        const [x2, y2, z2] = pt(nodes[j][0], nodes[j][1], nodes[j][2]);
        const depth = ((z1 + z2) / 2 + 1) / 2;
        lines.push({
          x1,
          y1,
          x2,
          y2,
          white: 0.42,
          a: (1 - dist / thr) * (0.3 + 0.55 * depth),
          w: Math.max(0.6, (o.lineW ?? 0.8) * rs)
        });
      }
    }
    for (let i = 0; i < nodeN; i++) {
      const [px, py, z] = pt(nodes[i][0], nodes[i][1], nodes[i][2]);
      const depth = (z + 1) / 2;
      const pulse = 1 + 0.25 * Math.sin(t * 1.4 + i * 2.7);
      dots.push({
        x: px,
        y: py,
        z,
        r: (nodeR + nodeRDepth * depth) * pulse * rs,
        white: 0.55 - 0.45 * depth
      });
    }
    const signals = o.signals ?? 5;
    for (let s = 0; s < signals; s++) {
      const seg = Math.floor(t * 0.55 + s * 7.31);
      const a = Math.floor(hashD(seg, s * 3.1 + 1.7) * nodeN);
      const b = Math.floor(hashD(seg, s * 5.7 + 4.2) * nodeN);
      if (a === b) continue;
      const f = frac(t * 0.55 + s * 7.31);
      const x = lerp(nodes[a][0], nodes[b][0], f);
      const y = lerp(nodes[a][1], nodes[b][1], f);
      const z = lerp(nodes[a][2], nodes[b][2], f);
      const l = Math.max(1e-6, Math.sqrt(x * x + y * y + z * z));
      const [px, py, zr] = pt(x / l, y / l, z / l);
      const depth = (zr + 1) / 2;
      dots.push({
        x: px,
        y: py,
        z: zr,
        r: (nodeR * 1.5 + nodeRDepth * depth) * rs,
        white: 0.05,
        a: 0.5 + 0.5 * depth
      });
    }
    return finalizeFrame(dots, lines, o.rMin);
  };
  var MODE_FRAMES = {
    orbits: frameOrbits,
    globe: frameGlobe,
    rubik: frameRubik,
    wave: frameWave,
    web: frameWeb,
    braid: frameBraid,
    ribbon: frameRibbon,
    // ring shares ribbon's geometry — the `faceOn` profile flag switches it
    ring: frameRibbon,
    morph: frameMorph
  };
  var MODE_DRAWS = Object.fromEntries(
    Object.entries(MODE_FRAMES).map(([key, frame]) => [
      key,
      (ctx, size, t, dark, opts) => paintFrame(ctx, frame(size, t, opts), dark)
    ])
  );
  var STATE_TO_MODE = {
    working: "orbits",
    searching: "globe",
    solving: "rubik",
    listening: "wave",
    connecting: "web",
    weaving: "braid",
    composing: "ribbon",
    breathing: "ring",
    shaping: "morph"
  };
  var PRESETS = {
    orbits: {
      64: { speed: 1.885, count: 1, size: 1 },
      32: { speed: 2.9072, count: 0.4251, size: 1.6849 },
      20: { speed: 3.9, count: 0.238, size: 2.4 }
    },
    globe: {
      64: { speed: 2.015, count: 0.42, size: 1.15, extra: { scanMul: 4.08, dimBase: 0.45 } },
      32: { speed: 2.3803, count: 0.1839, size: 1.4769, extra: { scanMul: 4.2301, dimBase: 0.45 } },
      20: { speed: 2.665, count: 0.105, size: 1.75, extra: { scanMul: 4.335, dimBase: 0.45 } }
    },
    rubik: {
      64: { speed: 1.82, count: 0.35, size: 1.05 },
      32: { speed: 1.8964, count: 0.1537, size: 1.4951 },
      20: { speed: 1.95, count: 0.088, size: 1.9 }
    },
    wave: {
      64: { speed: 4.388, count: 0.341, size: 1 },
      32: { speed: 4.1512, count: 0.169, size: 1.3232 },
      20: { speed: 3.998, count: 0.105, size: 1.6 }
    },
    web: {
      64: { speed: 3.315, count: 1.35, size: 0.95 },
      32: { speed: 5.0104, count: 0.4942, size: 1.2571 },
      20: { speed: 6.63, count: 0.25, size: 1.52 }
    },
    braid: {
      64: { speed: 1.625, count: 0.5, size: 1 },
      32: { speed: 2.2234, count: 0.2056, size: 1.2011 },
      20: { speed: 2.75, count: 0.1125, size: 1.36 }
    },
    ribbon: {
      64: { speed: 2.34, count: 0.25, size: 0.85, extra: { spin: 0, bandMul: 3.9, wobMul: 1 } },
      32: { speed: 2.7776, count: 0.0969, size: 0.9766, extra: { spin: 0, bandMul: 4.49, wobMul: 1 } },
      20: { speed: 3.12, count: 0.051, size: 1.073, extra: { spin: 0, bandMul: 4.94, wobMul: 1 } }
    },
    ring: {
      64: { speed: 3.24, count: 0.25, size: 0.956, extra: { spin: 0, bandMul: 3.627, wobMul: 0.368 } },
      32: { speed: 3.5517, count: 0.0678, size: 1.31, extra: { spin: 0, bandMul: 3.8265, wobMul: 0.4751 } },
      20: { speed: 3.78, count: 0.028, size: 1.622, extra: { spin: 0, bandMul: 3.968, wobMul: 0.565 } }
    },
    morph: {
      64: { speed: 2.405, count: 0.702, size: 0.395, extra: { spread: 1.45 } },
      32: { speed: 2.2057, count: 0.5937, size: 0.6916, extra: { spread: 1.45 } },
      20: { speed: 2.08, count: 0.53, size: 1.011, extra: { spread: 1.45 } }
    }
  };
  var cache = /* @__PURE__ */ new Map();
  function resolvePreset(state, size) {
    const key = `${state}-${size}`;
    const hit = cache.get(key);
    if (hit) return hit;
    const mode = STATE_TO_MODE[state];
    const preset = PRESETS[mode][size];
    let opts = { ...BASE_PROFILES[mode] };
    if (preset.count !== 1) opts = scaleCounts(opts, preset.count);
    if (preset.size !== 1) opts = scaleRadii(opts, preset.size);
    if (preset.extra) opts = { ...opts, ...preset.extra };
    const resolved = { mode, speed: preset.speed, opts };
    cache.set(key, resolved);
    return resolved;
  }

  // src/content/voice-overlay.ts
  var PHASE_LOOK = {
    listening: { orb: "listening", headline: "Listening\u2026 speak now" },
    transcribing: { orb: "connecting", headline: "Heard you \u2014 transcribing\u2026" },
    transcript: { orb: "connecting", headline: "Heard you \u2014 transcribing\u2026" },
    thinking: { orb: "solving", headline: "Thinking\u2026" },
    awaiting: { orb: "breathing", headline: "Waiting for you\u2026" },
    speaking: { orb: "composing", headline: "Speaking\u2026" },
    done: { orb: "breathing", headline: "Done" },
    error: { orb: "breathing", headline: "Something went wrong" },
    busy: { orb: "listening", headline: "Already listening\u2026" }
  };
  var ORB_SIZE = 64;
  var HIDE_AFTER_DONE_MS = 5e3;
  var ABSOLUTE_CAP_MS = 9e4;
  function prefersReducedMotion(win) {
    try {
      return typeof win.matchMedia === "function" && win.matchMedia("(prefers-reduced-motion: reduce)").matches;
    } catch {
      return false;
    }
  }
  var VoiceOverlay = class {
    host = null;
    root = null;
    canvas = null;
    ctx = null;
    headlineEl = null;
    detailEl = null;
    levelFill = null;
    levelWrap = null;
    stopEl = null;
    confirmEl = null;
    phase = null;
    /** Last custom headline shown (worker thinking text). Restored when a
     *  cancel-confirm "No" resumes the turn, so live thinking is never
     *  downgraded back to the generic phase headline. Null = default look. */
    lastHeadline = null;
    rafId = 0;
    t0 = 0;
    currentOrb = "breathing";
    hideTimer = 0;
    capTimer = 0;
    doc;
    win;
    onStop;
    constructor(doc = document, opts = {}) {
      this.doc = doc;
      this.win = doc.defaultView ?? window;
      this.onStop = opts.onStop ?? (() => {
        try {
          const rt = globalThis.chrome?.runtime;
          const send = rt?.sendMessage;
          if (typeof send !== "function") return;
          send({
            type: "CANCEL_TASK",
            requestId: `stop_${Date.now()}`,
            payload: { silent: true }
          });
          send({
            type: "TTS_STOP",
            requestId: `stop_${Date.now()}_tts`,
            payload: { all: true, target: "offscreen" }
          });
          send({
            type: "VOICE_CAPTURE_STOP",
            requestId: `stop_${Date.now()}_cap`,
            payload: { target: "offscreen" }
          });
        } catch {
        }
      });
    }
    /** Current phase (null when hidden). Test introspection. */
    currentPhase() {
      return this.phase;
    }
    /** Headline text currently shown. Test introspection. */
    currentHeadline() {
      return this.headlineEl?.textContent ?? "";
    }
    /** Detail text currently shown. Test introspection. */
    currentDetail() {
      return this.detailEl?.textContent ?? "";
    }
    /** Whether the Stop control is currently shown. Test introspection. */
    stopControlVisible() {
      return this.stopEl !== null && this.stopEl.style.display !== "none";
    }
    /** Whether the cancel-confirm prompt is showing. Test introspection. */
    confirmVisible() {
      return this.confirmEl !== null && this.confirmEl.style.display !== "none";
    }
    /**
     * Requests cancellation (Stop hover or click path — both converge here).
     * Shows an inline "Cancel this turn? Yes / No" prompt instead of acting
     * immediately, so a stray cursor pass can never kill a turn unasked.
     */
    requestStop() {
      try {
        this.ensureHost();
        if (this.host === null || this.confirmEl === null || this.headlineEl === null) return;
        if (this.confirmEl.style.display !== "none") return;
        this.confirmEl.style.display = "flex";
        if (this.stopEl !== null) this.stopEl.style.display = "none";
        this.headlineEl.textContent = "Cancel this turn?";
      } catch {
      }
    }
    /** Confirm-choice handler (Yes executes the stop, No resumes display). */
    resolveStop(confirm) {
      try {
        if (this.confirmEl !== null) this.confirmEl.style.display = "none";
        if (this.stopEl !== null) this.stopEl.style.display = "";
        if (confirm) {
          this.hide();
          this.onStop();
        } else if (this.phase !== null && this.headlineEl !== null) {
          const look = PHASE_LOOK[this.phase];
          this.headlineEl.textContent = this.lastHeadline ?? look.headline;
        }
      } catch {
      }
    }
    /** Activates the Stop control (same path as a pointer click). Test + a11y. */
    pressStop() {
      try {
        this.requestStop();
      } catch {
      }
    }
    /** Test seam: answer the confirm prompt directly. */
    pressConfirm(confirm) {
      try {
        this.resolveStop(confirm);
      } catch {
      }
    }
    /**
     * Worker-driven status update. Agent thinking ("Reasoning… (step 3)",
     * "Searching the web…") is the turn's HEADLINE — prominent — while
     * transcripts and questions stay detail text under their phase headline.
     */
    showStatus(phase, text) {
      const clean = typeof text === "string" ? text : "";
      if (phase === "thinking" && clean !== "") {
        this.show(phase, { headline: clean });
      } else {
        this.show(phase, { ...clean !== "" ? { detail: clean } : {} });
      }
    }
    show(phase, opts = {}) {
      try {
        this.ensureHost();
        if (this.host === null || this.root === null) return;
        this.phase = phase;
        this.lastHeadline = opts.headline ?? null;
        const look = PHASE_LOOK[phase];
        this.currentOrb = look.orb;
        if (this.headlineEl !== null) {
          this.headlineEl.textContent = opts.headline ?? look.headline;
        }
        if (this.detailEl !== null) {
          const detail = opts.detail ?? "";
          this.detailEl.textContent = detail;
          this.detailEl.style.display = detail === "" ? "none" : "";
        }
        if (this.levelWrap !== null) {
          this.levelWrap.style.display = phase === "listening" ? "" : "none";
        }
        this.host.style.display = "";
        this.restartPainter();
        this.win.clearTimeout(this.hideTimer);
        this.hideTimer = 0;
        if (phase === "done" || phase === "error") {
          if (this.confirmEl !== null) this.confirmEl.style.display = "none";
          if (this.stopEl !== null) this.stopEl.style.display = "";
          this.hideTimer = this.win.setTimeout(() => this.hide(), HIDE_AFTER_DONE_MS);
        } else if (this.confirmEl !== null && this.confirmEl.style.display !== "none") {
          if (this.headlineEl !== null) this.headlineEl.textContent = "Cancel this turn?";
        } else {
          if (this.capTimer === 0) {
            this.capTimer = this.win.setTimeout(() => this.hide(), ABSOLUTE_CAP_MS);
          }
        }
      } catch {
      }
    }
    /** Live mic RMS (0..~0.3 speech). Only visible during listening. */
    setLevel(level) {
      try {
        if (this.phase !== "listening" || this.levelFill === null) return;
        const pct = Number.isFinite(level) ? level * 100 : 0;
        const width = Math.max(0, Math.min(100, pct * 5));
        this.levelFill.style.width = `${width.toFixed(0)}%`;
        this.levelFill.style.background = pct >= 2 ? "#4ade80" : "#f59e0b";
      } catch {
      }
    }
    hide() {
      try {
        this.phase = null;
        this.lastHeadline = null;
        this.stopPainter();
        this.win.clearTimeout(this.hideTimer);
        this.win.clearTimeout(this.capTimer);
        this.hideTimer = 0;
        this.capTimer = 0;
        if (this.host !== null) this.host.style.display = "none";
      } catch {
      }
    }
    // -- DOM ---------------------------------------------------------------------
    ensureHost() {
      if (this.host !== null && this.root !== null) return;
      const docEl = this.doc.documentElement;
      if (docEl === null) return;
      const host = this.doc.createElement("div");
      host.setAttribute("id", "inviz-voice-overlay");
      host.setAttribute("role", "status");
      host.setAttribute("aria-live", "polite");
      host.setAttribute("aria-label", "INVIZ voice status");
      host.style.cssText = "position:fixed;left:50%;bottom:24px;transform:translateX(-50%);z-index:2147483647;pointer-events:none;display:none;";
      let root;
      try {
        root = host.attachShadow({ mode: "closed" });
      } catch {
        return;
      }
      const style = this.doc.createElement("style");
      style.textContent = ".pill{display:flex;align-items:center;gap:12px;max-width:min(480px,90vw);background:rgba(17,17,20,.92);color:#f5f5f5;border:1px solid rgba(255,255,255,.12);border-radius:16px;padding:10px 16px 10px 10px;font:13px/1.45 system-ui,-apple-system,sans-serif;box-shadow:0 8px 32px rgba(0,0,0,.45);backdrop-filter:blur(8px)}canvas{width:64px;height:64px;flex:none}.txt{min-width:0}.head{font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.detail{opacity:.8;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}.meter{height:6px;background:rgba(255,255,255,.15);border-radius:3px;margin-top:6px;overflow:hidden}.meter>i{display:block;height:100%;width:0%;background:#f59e0b;border-radius:3px;transition:width 120ms linear}";
      const pill = this.doc.createElement("div");
      pill.setAttribute("class", "pill");
      const canvas = this.doc.createElement("canvas");
      canvas.setAttribute("width", String(ORB_SIZE * 2));
      canvas.setAttribute("height", String(ORB_SIZE * 2));
      canvas.setAttribute("aria-hidden", "true");
      const txt = this.doc.createElement("div");
      txt.setAttribute("class", "txt");
      const head = this.doc.createElement("div");
      head.setAttribute("class", "head");
      const detail = this.doc.createElement("div");
      detail.setAttribute("class", "detail");
      detail.style.display = "none";
      const meter = this.doc.createElement("div");
      meter.setAttribute("class", "meter");
      const fill = this.doc.createElement("i");
      meter.appendChild(fill);
      txt.append(head, detail, meter);
      const stop = this.doc.createElement("button");
      stop.setAttribute("type", "button");
      stop.setAttribute("aria-label", "Stop INVIZ voice");
      stop.textContent = "\u2715";
      stop.style.cssText = "pointer-events:auto;flex:none;width:36px;height:36px;border-radius:50%;border:1px solid rgba(255,255,255,.25);background:rgba(255,255,255,.08);color:#f5f5f5;font-size:15px;line-height:1;cursor:pointer;";
      stop.addEventListener("click", (e) => {
        e.stopPropagation();
        this.requestStop();
      });
      stop.addEventListener("mouseenter", () => {
        this.requestStop();
      });
      const confirm = this.doc.createElement("div");
      confirm.style.cssText = "display:none;align-items:center;gap:8px;pointer-events:auto;";
      const yes = this.doc.createElement("button");
      yes.setAttribute("type", "button");
      yes.textContent = "Yes, stop";
      const no = this.doc.createElement("button");
      no.setAttribute("type", "button");
      no.textContent = "No";
      for (const b of [yes, no]) {
        b.style.cssText = "pointer-events:auto;border-radius:8px;border:1px solid rgba(255,255,255,.25);background:rgba(255,255,255,.08);color:#f5f5f5;font-size:13px;padding:6px 12px;cursor:pointer;";
      }
      yes.addEventListener("click", (e) => {
        e.stopPropagation();
        this.resolveStop(true);
      });
      no.addEventListener("click", (e) => {
        e.stopPropagation();
        this.resolveStop(false);
      });
      confirm.append(yes, no);
      pill.append(canvas, txt, stop, confirm);
      root.append(style, pill);
      docEl.appendChild(host);
      this.host = host;
      this.root = root;
      this.canvas = canvas;
      this.headlineEl = head;
      this.detailEl = detail;
      this.levelFill = fill;
      this.levelWrap = meter;
      this.stopEl = stop;
      this.confirmEl = confirm;
      try {
        this.ctx = typeof canvas.getContext === "function" ? canvas.getContext("2d") : null;
      } catch {
        this.ctx = null;
      }
    }
    // -- Orb painter ---------------------------------------------------------------
    restartPainter() {
      this.stopPainter();
      if (this.ctx === null || this.canvas === null) return;
      if (prefersReducedMotion(this.win)) {
        this.paintFrame(1);
        return;
      }
      this.t0 = this.win.performance.now();
      const tick = (now) => {
        this.rafId = this.win.requestAnimationFrame(tick);
        try {
          const { speed, opts, mode } = resolvePreset(this.currentOrb, ORB_SIZE);
          const t = (now - this.t0) / 1e3 * speed;
          const ctx = this.ctx;
          const canvas = this.canvas;
          if (ctx === null || canvas === null) return;
          const k = (canvas.width || ORB_SIZE * 2) / ORB_SIZE;
          ctx.save();
          ctx.scale(k, k);
          ctx.clearRect(0, 0, ORB_SIZE, ORB_SIZE);
          MODE_DRAWS[mode](ctx, ORB_SIZE, t, true, opts);
          ctx.restore();
        } catch {
          this.stopPainter();
        }
      };
      this.rafId = this.win.requestAnimationFrame(tick);
    }
    paintFrame(t) {
      try {
        if (this.ctx === null || this.canvas === null) return;
        const { speed, opts, mode } = resolvePreset(this.currentOrb, ORB_SIZE);
        const k = (this.canvas.width || ORB_SIZE * 2) / ORB_SIZE;
        this.ctx.save();
        this.ctx.scale(k, k);
        this.ctx.clearRect(0, 0, ORB_SIZE, ORB_SIZE);
        MODE_DRAWS[mode](this.ctx, ORB_SIZE, t * speed, true, opts);
        this.ctx.restore();
      } catch {
      }
    }
    stopPainter() {
      if (this.rafId !== 0) {
        try {
          this.win.cancelAnimationFrame(this.rafId);
        } catch {
        }
        this.rafId = 0;
      }
    }
  };

  // src/content/content.ts
  function isTopFrame() {
    try {
      return window.top === window.self;
    } catch {
      return false;
    }
  }
  var lens = new ContextLens();
  var pendingAnnouncements = [];
  var MAX_PENDING = 20;
  var lastAnnouncement = null;
  function pageLang() {
    const tag = (document.documentElement.lang || "en").toLowerCase();
    return tag.startsWith("hi") ? "hi" : "en";
  }
  var monitor = new FocusMonitor((el) => {
    const { elementId, generation } = lens.identify(el);
    const role = resolveRole(el);
    const { name } = computeAccessibleName(el, document);
    const states = extractStates(el, role);
    void generation;
    return { elementId, name, role, states };
  });
  monitor.setLang(pageLang());
  async function voicelensOn() {
    try {
      const cfg = await chrome.storage.local.get(STORAGE_KEY_CONFIG);
      const flag = cfg[STORAGE_KEY_CONFIG];
      return flag?.voicelensEnabled === true;
    } catch {
      return false;
    }
  }
  function speakLive(text, lang) {
    if (text.trim() === "") return;
    void voicelensOn().then((on) => {
      if (!on || !contextAlive()) return;
      try {
        chrome.runtime.sendMessage({
          type: "TTS_SPEAK",
          requestId: `speak_${Date.now()}`,
          payload: { text, lang, priority: 5 }
        }).catch(() => void 0);
      } catch {
        contextDead = true;
      }
    });
  }
  monitor.onAnnouncement((a) => {
    lastAnnouncement = a;
    pendingAnnouncements.push(a);
    if (pendingAnnouncements.length > MAX_PENDING) {
      pendingAnnouncements.shift();
    }
    speakLive(a.text, a.lang);
  });
  function deepHoverTarget(e) {
    const t = e.target;
    if (!(t instanceof Element)) return null;
    try {
      const deep = document.elementFromPoint(e.clientX, e.clientY);
      if (deep instanceof Element && deep !== t && isDescendantComposed(t, deep)) {
        return deep;
      }
    } catch {
    }
    return t;
  }
  var hoverCoalescer = new HoverCoalescer((el) => {
    const announcement = monitor.handleHover(el);
    if (announcement === null) lastAnnouncement = null;
  });
  document.addEventListener(
    "mouseover",
    (e) => {
      if (!isTopFrame()) return;
      if (!(e instanceof MouseEvent)) return;
      const target = deepHoverTarget(e);
      if (target === null) return;
      hoverCoalescer.push(target);
    },
    true
  );
  var contextDead = false;
  function contextAlive() {
    if (contextDead) return false;
    try {
      if (chrome?.runtime?.id === void 0) {
        contextDead = true;
        try {
          observer.stop();
        } catch {
        }
        try {
          monitor.stop();
        } catch {
        }
        return false;
      }
      return true;
    } catch {
      contextDead = true;
      return false;
    }
  }
  function pushSnapshot() {
    if (!isTopFrame() || !contextAlive()) return;
    const state = lens.extract(document);
    const snapshot = {
      url: state.url,
      title: state.title,
      generation: state.generation,
      items: lens.registry.snapshot(),
      // Structure and prose travel with the snapshot: without them the model
      // receives a list of widgets and nothing about what the page says.
      structure: state.structure,
      prose: state.prose,
      skipped: state.skipped,
      savedAt: Date.now()
    };
    try {
      chrome.runtime.sendMessage({
        type: "PAGE_STATE_UPDATED",
        requestId: `req_${Date.now()}`,
        payload: { state: snapshot }
      }).catch(() => {
        logger.debug("snapshot: service worker unavailable (extension reloading?)");
      });
    } catch {
      contextDead = true;
      logger.debug("snapshot: extension context invalidated \u2014 parked until reload");
    }
  }
  var observer = new PageObserver(document, {
    onTrigger: (trigger, detail) => {
      logger.debug("page trigger", { trigger, detail });
      if (trigger === "minor") return;
      pushSnapshot();
      if (trigger === "route") {
        const urlAtRoute = location.href;
        for (const delayMs of [1200, 3200]) {
          setTimeout(() => {
            if (location.href !== urlAtRoute) return;
            pushSnapshot();
          }, delayMs);
        }
      }
    }
  });
  var agentActive = false;
  var lastOverrideSent = 0;
  function onTrustedUserInput(kind) {
    if (!agentActive) return;
    const now = Date.now();
    if (now - lastOverrideSent < 1e3) return;
    lastOverrideSent = now;
    agentActive = false;
    if (!contextAlive()) return;
    try {
      chrome.runtime.sendMessage({
        type: "USER_OVERRIDE",
        requestId: `ovr_${now}`,
        payload: { kind }
      }).catch(() => void 0);
    } catch {
      contextDead = true;
    }
  }
  for (const event of ["keydown", "click", "wheel"]) {
    document.addEventListener(
      event,
      (e) => {
        if (!isTopFrame()) return;
        if (e.isTrusted) onTrustedUserInput(event);
      },
      true
    );
  }
  function identityPresent(identity) {
    if (identity === null) return null;
    const fresh = lens.extract(document);
    void fresh;
    for (const item of lens.registry.snapshot()) {
      if (item.role === identity.role && item.name === identity.name) return true;
    }
    return false;
  }
  function collectFacts(payload, actionGeneration) {
    const urlNow = location.href;
    const currentGen = lens.registry.currentGeneration;
    let activeMatches = null;
    let fieldFilled = null;
    let stateMatches = null;
    const expect = payload.expect;
    if ((expect.type === "focused_element" || expect.type === "field_value_present" || expect.type === "element_state") && expect.target !== void 0) {
      const resolved = lens.registry.resolve(expect.target, currentGen);
      if (resolved.ok) {
        const el = resolved.entry.element;
        if (expect.type === "focused_element") {
          activeMatches = document.activeElement === el;
        }
        if (expect.type === "field_value_present") {
          fieldFilled = fieldHasValue(el);
        }
        if (expect.type === "element_state" && expect.state !== void 0) {
          const live = (() => {
            if (expect.state === "checked") {
              if (el instanceof HTMLInputElement) return el.checked;
              const aria = el.getAttribute("aria-checked");
              if (aria === "true") return true;
              if (aria === "false") return false;
            }
            if (expect.state === "expanded") {
              const aria = el.getAttribute("aria-expanded");
              if (aria === "true") return true;
              if (aria === "false") return false;
            }
            if (expect.state === "selected") {
              const aria = el.getAttribute("aria-selected");
              if (aria === "true") return true;
              if (aria === "false") return false;
              if (el instanceof HTMLOptionElement) return el.selected;
            }
            if (expect.state === "pressed") {
              const aria = el.getAttribute("aria-pressed");
              if (aria === "true") return true;
              if (aria === "false") return false;
            }
            return null;
          })();
          if (live !== null) stateMatches = live === expect.stateValue;
          else {
            const states = resolved.entry.states;
            stateMatches = states[expect.state] === expect.stateValue;
          }
        }
      } else if (resolved.code === "STALE_TARGET" && payload.identity !== null) {
        const present = identityPresent(payload.identity);
        if (expect.type === "field_value_present") {
          fieldFilled = present === true ? null : false;
        }
        if (expect.type === "element_state") {
          stateMatches = present === true ? null : false;
        }
        if (expect.type === "focused_element") {
          activeMatches = false;
        }
      } else {
        if (expect.type === "field_value_present") fieldFilled = false;
        if (expect.type === "element_state") stateMatches = false;
        if (expect.type === "focused_element") activeMatches = false;
      }
    }
    let textFound = null;
    if (expect.type === "text_present") {
      if (typeof expect.value === "string" && expect.value !== "") {
        textFound = (document.body?.innerText ?? "").includes(expect.value);
      }
    }
    const submit = collectCompletionSignals(document, expect.target, {
      urlBefore: payload.urlBefore,
      resolveTarget: (id) => {
        const resolved = lens.registry.resolve(id, currentGen);
        return resolved.ok ? resolved.entry.element : null;
      },
      targetMissingFromRegistry: expect.target !== void 0 && !lens.registry.resolve(expect.target, currentGen).ok,
      identityMissing: expect.target === void 0 && payload.identity !== null ? identityPresent(payload.identity) === false : false
    });
    return {
      urlBefore: payload.urlBefore,
      urlNow,
      targetPresent: payload.identity !== null ? identityPresent(payload.identity) : null,
      activeMatches,
      dialogOpen: getOpenDialogs(document).length > 0,
      textFound,
      fieldFilled,
      stateMatches,
      generationChanged: currentGen !== actionGeneration,
      submit
    };
  }
  function handleObserveVerify(payload, sendResponse) {
    const startedAt = Date.now();
    const timeout = Math.min(Math.max(payload.timeoutMs, 100), 1e4);
    const tick = () => {
      const facts = collectFacts(payload, payload.actionGeneration);
      const verdict = evaluateExpectation(payload.expect, facts);
      if (verdict !== "PENDING") {
        sendResponse({
          ok: true,
          payload: {
            outcome: verdict,
            observed: {
              url: facts.urlNow,
              generation: lens.registry.currentGeneration
            },
            timedOut: false
          }
        });
        return;
      }
      if (Date.now() - startedAt >= timeout) {
        sendResponse({
          ok: true,
          payload: {
            outcome: "VERIFIED_FAILURE",
            observed: {
              url: facts.urlNow,
              generation: lens.registry.currentGeneration
            },
            timedOut: true
          }
        });
        return;
      }
      setTimeout(tick, 250);
    };
    tick();
  }
  function readRegionText(targetId, maxChars) {
    const cap = Math.min(Math.max(maxChars, 100), 2e4);
    let source = null;
    if (targetId !== void 0) {
      const prose = lens.proseRegions();
      const regionMatch = /^r\d+$/.exec(targetId);
      if (regionMatch !== null) {
        const index = Number(targetId.slice(1)) - 1;
        const region = prose[index];
        if (region !== void 0) return region.text.slice(0, cap);
      }
      const resolved = lens.registry.resolve(targetId, lens.registry.currentGeneration);
      if (resolved.ok) source = lens.proseFor(resolved.entry.element);
    }
    if (source === null) {
      const prose = lens.proseRegions();
      const primary = prose[0];
      if (primary !== void 0) return primary.text.slice(0, cap);
      source = document.querySelector("main, article, [role='main']") ?? document.body;
    }
    if (source === null) return "";
    const text = (source.textContent ?? "").replace(/\s+/g, " ").trim();
    return text.slice(0, cap);
  }
  var voiceOverlay = new VoiceOverlay();
  function showMicLevel(level) {
    voiceOverlay.setLevel(level);
  }
  function showVoiceStatus(payload) {
    const phase = payload["phase"];
    if (phase !== "listening" && phase !== "transcribing" && phase !== "transcript" && phase !== "thinking" && phase !== "awaiting" && phase !== "speaking" && phase !== "done" && phase !== "error" && phase !== "busy") {
      return;
    }
    const text = payload["text"];
    voiceOverlay.showStatus(
      phase,
      typeof text === "string" ? text : void 0
    );
  }
  if (isTopFrame()) {
    pushSnapshot();
    monitor.start();
    observer.start();
    logger.info("content script wired (Phase 1+5)", { url: location.href });
  } else {
    logger.debug("content script parked (subframe; top frame owns the tab)");
  }
  chrome.runtime.onMessage.addListener(
    (message, _sender, sendResponse) => {
      if (!isTopFrame()) return false;
      if (!isExtensionMessage(message)) {
        sendResponse({ ok: false, errorCode: "SCHEMA_VALIDATION_FAILED" });
        return false;
      }
      switch (message.type) {
        case "CAPTURE_LEVEL": {
          const level = message.payload["level"];
          if (typeof level === "number") showMicLevel(level);
          return false;
        }
        case "VOICE_STATUS": {
          showVoiceStatus(message.payload);
          return false;
        }
        case "FOCUS_CHANGED": {
          sendResponse({
            ok: true,
            pending: pendingAnnouncements.length,
            announcement: lastAnnouncement === null ? null : {
              text: lastAnnouncement.text,
              name: lastAnnouncement.name,
              role: lastAnnouncement.role
            }
          });
          return false;
        }
        case "ACTION_EXECUTE": {
          const action = message.payload["action"];
          if (typeof action !== "object" || action === null) {
            sendResponse({ ok: false, errorCode: "SCHEMA_VALIDATION_FAILED" });
            return false;
          }
          void performDomAction(
            action,
            lens.registry,
            lens.registry.currentGeneration
          ).then((result) => {
            sendResponse({
              ok: result.ok,
              payload: result.ok ? { ok: true } : { ok: false, errorCode: result.errorCode ?? "ACTION_FAILED" }
            });
          });
          return true;
        }
        case "OBSERVE_VERIFY": {
          const payload = message.payload;
          if (typeof payload !== "object" || payload === null || typeof payload.timeoutMs !== "number") {
            sendResponse({ ok: false, errorCode: "SCHEMA_VALIDATION_FAILED" });
            return false;
          }
          handleObserveVerify(payload, sendResponse);
          return true;
        }
        case "READ_TEXT": {
          const target = message.payload["target"];
          const maxChars = message.payload["maxChars"];
          const text = readRegionText(
            typeof target === "string" ? target : void 0,
            typeof maxChars === "number" ? maxChars : 4e3
          );
          sendResponse({ ok: true, payload: { ok: true, text } });
          return false;
        }
        case "REQUEST_SNAPSHOT": {
          try {
            const state = lens.extract(document);
            const snapshot = {
              url: state.url,
              title: state.title,
              generation: state.generation,
              items: lens.registry.snapshot(),
              structure: state.structure,
              prose: state.prose,
              skipped: state.skipped,
              savedAt: Date.now()
            };
            pushSnapshot();
            sendResponse({ ok: true, payload: { state: snapshot } });
          } catch {
            sendResponse({ ok: false, errorCode: "ACTION_FAILED" });
          }
          return false;
        }
        case "AGENT_ACTIVE": {
          agentActive = message.payload["active"] === true;
          sendResponse({ ok: true, agentActive });
          return false;
        }
        default:
          sendResponse({ ok: true, phase: 5, url: location.href });
          return false;
      }
    }
  );
})();
//# sourceMappingURL=content.js.map
